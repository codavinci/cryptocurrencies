---
name: Feature Request
about: Suggest a new feature for the rippled project
title: "[Title with short description] (Version: [rippled version])"
labels: Feature Request
assignees: ''

---
<!-- Please search existing issues to avoid creating duplicates.-->

## Summary
<!-- Provide a summary to the feature request-->

## Motivation
<!-- Why do we need this feature?-->

## Solution
<!-- What is the solution?-->

## Paths Not Taken
<!-- What other alternatives have been considered?-->
