#!/bin/bash -ev

git archive --format=tar.gz -o peercoin.tar.gz --prefix=/peercoin/ HEAD .

