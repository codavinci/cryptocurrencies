#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_BEAST_WARNINGS
#include <boost/process/child.hpp>
REENABLE_WARNINGS
