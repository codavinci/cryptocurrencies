#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_ASIO_WARNINGS
#include <boost/asio/ip/address_v6.hpp>
REENABLE_WARNINGS
