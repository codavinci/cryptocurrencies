#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_ASIO_WARNINGS
#include <boost/asio/deadline_timer.hpp>
REENABLE_WARNINGS
