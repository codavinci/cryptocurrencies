#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_ASIO_WARNINGS
#include <boost/asio/buffer.hpp>
REENABLE_WARNINGS
