#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_ASIO_WARNINGS
#include <boost/asio/basic_stream_socket.hpp>
REENABLE_WARNINGS
