#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_BEAST_WARNINGS
#include <boost/beast/version.hpp>
REENABLE_WARNINGS
