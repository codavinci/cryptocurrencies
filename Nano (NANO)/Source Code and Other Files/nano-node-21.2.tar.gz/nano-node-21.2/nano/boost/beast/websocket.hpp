#pragma once

#include <nano/boost/private/macro_warnings.hpp>

DISABLE_BEAST_WARNINGS
#include <boost/beast/websocket.hpp>
REENABLE_WARNINGS
