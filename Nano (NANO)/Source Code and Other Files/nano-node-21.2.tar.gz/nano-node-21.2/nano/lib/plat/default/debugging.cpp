#include <nano/lib/utility.hpp>

void nano::create_load_memory_address_files ()
{
}
