#include <nano/lib/utility.hpp>

void nano::work_thread_reprioritize ()
{
}
