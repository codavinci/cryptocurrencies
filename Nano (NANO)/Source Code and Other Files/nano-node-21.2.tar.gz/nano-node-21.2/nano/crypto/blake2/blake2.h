#pragma once

#ifdef _WIN32
#pragma warning(push)
#pragma warning(disable : 4804)
#endif

#include <crypto/blake2/blake2.h>

#ifdef _WIN32
#pragma warning(pop)
#endif
