#include <gtest/gtest.h>

TEST (basic, basic)
{
	ASSERT_TRUE (true);
}
