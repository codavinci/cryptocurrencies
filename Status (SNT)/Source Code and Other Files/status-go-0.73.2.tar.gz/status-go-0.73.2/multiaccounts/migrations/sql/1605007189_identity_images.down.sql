DROP TABLE identity_images;
