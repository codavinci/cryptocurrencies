DROP TABLE accounts;
