package accounts

const (
	// NodeConfigTag tag for a node configuration.
	NodeConfigTag = "node_config"
)
