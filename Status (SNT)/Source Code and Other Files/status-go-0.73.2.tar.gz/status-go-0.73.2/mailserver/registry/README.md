### Mailserver registry

The code for the contract interface used is at https://github.com/status-im/network-incentivisation/blob/master/contracts/Nodes.sol
 and has been generated with abigen.

`abigen --sol contracts/Nodes.sol --pkg registry`
