// +build !nimbus

package statusgo

import (
	"github.com/status-im/status-go/api"
)

var statusBackend = api.NewGethStatusBackend()
