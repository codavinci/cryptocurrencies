ALTER TABLE installations ADD version INTEGER DEFAULT 0;
