DROP TABLE sessions;
DROP TABLE bundles;
DROP TABLE keys;
DROP TABLE ratchet_info;
