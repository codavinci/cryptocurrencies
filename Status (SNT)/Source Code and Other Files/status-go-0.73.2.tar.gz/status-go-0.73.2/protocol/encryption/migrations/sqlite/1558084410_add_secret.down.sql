DROP TABLE secret_installation_ids;
DROP TABLE secrets;
