DROP TABLE contact_code_config;
