DROP TABLE installations_metadata;
