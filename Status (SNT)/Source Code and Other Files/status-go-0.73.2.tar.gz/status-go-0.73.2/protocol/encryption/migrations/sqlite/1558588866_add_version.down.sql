ALTER TABLE installations DROP COLUMN version;
