ALTER TABLE keys DROP COLUMN session_id;
ALTER TABLE sessions DROP COLUMN keys_count;
ALTER TABLE bundles DROP COLUMN version;
