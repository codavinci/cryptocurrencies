DROP TABLE installations;
