CREATE TABLE IF NOT EXISTS push_notification_server_notifications (
  id BLOB NOT NULL,
  UNIQUE(id)
);
