ALTER TABLE user_messages ADD COLUMN mentions BLOB;
