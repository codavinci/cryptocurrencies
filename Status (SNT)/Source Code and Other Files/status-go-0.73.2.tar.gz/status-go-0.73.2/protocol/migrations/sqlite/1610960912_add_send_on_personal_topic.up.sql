ALTER TABLE raw_messages ADD COLUMN send_on_personal_topic BOOLEAN DEFAULT FALSE;
