DROP TABLE chats;
DROP TABLE user_messages;
DROP TABLE contacts;
