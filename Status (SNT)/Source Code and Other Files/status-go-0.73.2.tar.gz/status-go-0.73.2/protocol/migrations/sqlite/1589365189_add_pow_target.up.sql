ALTER TABLE raw_messages ADD COLUMN pow_target REAL default 0.02;
