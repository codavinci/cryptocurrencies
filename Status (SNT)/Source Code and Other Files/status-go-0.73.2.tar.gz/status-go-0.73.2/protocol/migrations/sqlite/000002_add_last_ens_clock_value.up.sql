ALTER TABLE contacts ADD COLUMN last_ens_clock_value INT NOT NULL DEFAULT 0;
