ALTER TABLE raw_messages ADD COLUMN skip_group_message_wrap BOOLEAN DEFAULT FALSE;
