package types

// Filter represents a Whisper message filter
type Filter interface {
	ID() string
}
