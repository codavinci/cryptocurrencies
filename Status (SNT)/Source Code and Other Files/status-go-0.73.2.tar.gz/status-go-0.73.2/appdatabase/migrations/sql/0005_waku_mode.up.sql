ALTER TABLE settings ADD COLUMN waku_enabled BOOLEAN DEFAULT false;
ALTER TABLE settings ADD COLUMN waku_bloom_filter_mode BOOLEAN DEFAULT false;
