UPDATE settings SET waku_enabled = 1;
