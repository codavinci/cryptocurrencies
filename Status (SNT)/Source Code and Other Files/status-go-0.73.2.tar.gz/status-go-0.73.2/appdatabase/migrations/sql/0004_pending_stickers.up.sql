ALTER TABLE settings ADD COLUMN stickers_packs_pending BLOB;
