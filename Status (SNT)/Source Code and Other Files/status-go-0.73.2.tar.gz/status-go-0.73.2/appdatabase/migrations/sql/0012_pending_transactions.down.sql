DROP TABLE pending_transactions;
