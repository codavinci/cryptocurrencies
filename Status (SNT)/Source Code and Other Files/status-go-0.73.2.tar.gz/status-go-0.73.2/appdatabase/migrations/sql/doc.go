package sql

//go:generate go-bindata -pkg migrations -o ../bindata.go ./
