UPDATE settings SET send_push_notifications = 0;
