DROP TABLE favourites;
