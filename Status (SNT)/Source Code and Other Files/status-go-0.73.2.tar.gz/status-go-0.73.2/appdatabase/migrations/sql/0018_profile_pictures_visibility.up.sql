ALTER TABLE settings ADD COLUMN profile_pictures_visibility INT NOT NULL DEFAULT 1;
