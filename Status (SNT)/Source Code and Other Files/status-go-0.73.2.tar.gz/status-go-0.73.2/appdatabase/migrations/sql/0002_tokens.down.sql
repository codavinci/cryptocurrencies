DROP TABLE tokens;
