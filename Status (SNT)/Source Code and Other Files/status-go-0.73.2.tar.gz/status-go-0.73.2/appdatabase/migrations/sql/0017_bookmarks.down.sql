DROP TABLE bookmarks;
