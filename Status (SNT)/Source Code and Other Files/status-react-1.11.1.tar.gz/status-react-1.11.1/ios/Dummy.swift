//
//  Dummy.swift
//  StatusIm
//
//  Created by Gheorghe on 01.05.2020.
//  Copyright © 2020 Status. All rights reserved.
//

import Foundation
