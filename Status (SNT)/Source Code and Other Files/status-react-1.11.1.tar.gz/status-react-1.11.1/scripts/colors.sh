#!/usr/bin/env bash

# Colors
export YLW='\033[1;33m'
export RED='\033[0;31m'
export GRN='\033[0;32m'
export BLD='\033[1m'
export RST='\033[0m'

# Clear line
export CLR='\033[2K'
