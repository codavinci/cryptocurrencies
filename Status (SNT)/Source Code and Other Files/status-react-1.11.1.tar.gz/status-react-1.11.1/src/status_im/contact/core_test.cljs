(ns status-im.contact.core-test)

