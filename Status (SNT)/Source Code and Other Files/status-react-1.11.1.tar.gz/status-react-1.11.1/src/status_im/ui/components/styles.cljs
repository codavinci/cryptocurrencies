(ns status-im.ui.components.styles)

(def flex
  {:flex 1})

(def border-radius 8)
