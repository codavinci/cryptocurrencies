(ns status-im.browser.webview-ref)

(def webview-ref (atom nil))
