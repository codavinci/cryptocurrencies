module.exports = {
  entry: './src/js/index.js',
  output: {
    filename: 'index_bundle.js'
  }
}