`cd fiddle`

`yarn install`

`clj prepare.clj`
 
`clj -A:dev`