import React from 'react';
import ReactDOM from 'react-dom';
window.deps = {'react-native-web' : require('react-native-web') };
window.React = React;
window.ReactDOM = ReactDOM;
window.ReactNativeWeb = window.deps['react-native-web'];
