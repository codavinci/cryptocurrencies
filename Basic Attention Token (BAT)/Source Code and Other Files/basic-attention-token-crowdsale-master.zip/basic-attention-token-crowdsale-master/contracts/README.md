BAToken.sol: Basic Attention Token and crowdsale functionality

SafeMath.sol: safe add/subtract/multiply

StandardToken.sol: standard ERC20 functionality

BATSafe.sol: Lockup contract, presently without final addresses
