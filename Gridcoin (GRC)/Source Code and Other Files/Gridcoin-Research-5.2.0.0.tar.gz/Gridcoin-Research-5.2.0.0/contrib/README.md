This folder is for scripts, other tools, and files that are related to Gridcoin
but are not directly part of Gridcoin's code. 

These are not restricted to any one programming language so some scripts may need
Python, Perl, Bash, or other dependencies installed to run.