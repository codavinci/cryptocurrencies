Assets Attribution
===================

Icon: src/qt/res/icons/clock*.png,
      src/qt/res/src/*.svg
Designer: Wladimir van der Laan
License: MIT

Icon: src/qt/res/icons/export.png,
      src/qt/res/icons/key.png,
      src/qt/res/icons/filesave.png
Icon Pack: NUVOLA ICON THEME for KDE 3.x
Designer: David Vignoni (david@icon-king.com)
          ICON KING - www.icon-king.com
License: LGPL
Site: http://www.icon-king.com/projects/nuvola/

Icon: src/qt/res/icons/transaction*.png
Designer: md2k7
Site: https://forum.bitcoin.org/index.php?topic=15276.0
License: You are free to do with these icons as you wish, including selling,
 copying, modifying etc.

Icon: src/qt/res/icons/configure.png, src/qt/res/icons/quit.png,
      src/qt/res/icons/editcopy.png, src/qt/res/icons/editpaste.png,
      src/qt/res/icons/add.png, src/qt/res/icons/edit.png,
      src/qt/res/icons/remove.png (edited)
Designer: http://www.everaldo.com
Icon Pack: Crystal SVG
License: LGPL

Icon:  scripts/img/reload.xcf (modified),src/qt/res/movies/update_spinner.mng
Icon Pack: Kids
Designer: Everaldo (Everaldo Coelho)
License: GNU/GPL
Site: http://findicons.com/icon/17102/reload?id=17102

Gridcoin Logo: CryptoCoinTalk Community
