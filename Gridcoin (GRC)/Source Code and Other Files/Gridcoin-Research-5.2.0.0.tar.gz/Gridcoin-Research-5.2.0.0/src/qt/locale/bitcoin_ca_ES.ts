<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca_ES">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About Gridcoin</source>
        <translation>Sobre Gridcoin</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;Gridcoin&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+58"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or https://opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (https://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+63"/>
        <source>Create a new address</source>
        <translation>Crea una nova adreça</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;New</source>
        <translation>&amp;Nova</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia l&apos;adreça seleccionada al porta-retalls del sistema</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Delete the currently selected address from the list</source>
        <translation>Elimina l&apos;adreça sel·leccionada actualment de la llista</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Delete</source>
        <translation>&amp;Elimina</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+65"/>
        <source>Copy &amp;Label</source>
        <translation>Copia l&apos;eti&amp;queta</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <location line="+250"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Fitxer separat per comes (*.csv)</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="-119"/>
        <source>Address Book</source>
        <translation>Llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>These are your Gridcoin addresses for receiving payments. You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Aquestes són les teves adreces de Gridcoin per rebre els pagaments. És possible que vulgueu donar una diferent a cada remitent per a poder realitzar un seguiment de qui li está pagant.</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Double-click to edit address or label</source>
        <translation>Feu doble clic per editar l&apos;adreça o l&apos;etiqueta</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Show &amp;QR Code</source>
        <translation>Mostra el códi &amp;QR</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Sign a message to prove you own a Gridcoin address</source>
        <translation>Signar un missatge per demostrar que és propietari d&apos;una adreça Gridcoin</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Signar &amp;Message</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Verify a message to ensure it was signed with a specified Gridcoin address</source>
        <translation>Comproveu el missatge per assegurar-se que es va signar amb una adreça Gridcoin especificada.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verificar el missatge</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="-1"/>
        <source>Export Address Book Data</source>
        <translation>Exportar dades de la llibreta d&apos;adreces </translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Error exporting</source>
        <translation>Error a l&apos;exportar</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>No s&apos;ha pogut escriure al fitxer %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+145"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>Diàleg de contrasenya</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>Introduïu una contrasenya</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>Nova contrasenya</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>Repetiu la nova contrasenya</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+37"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Introduïu la contrasenya nova al moneder.&lt;br/&gt;Utilitzeu una contrasenya de &lt;b&gt;deu o més caràcters aleatoris&lt;/b&gt;, o &lt;b&gt;vuit o més paraules&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>Encripta el moneder</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Aquesta operació requereix la contrasenya del moneder per a desbloquejar-lo.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>Desbloqueja el moneder</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Aquesta operació requereix la contrasenya del moneder per desencriptar-lo.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>Desencripta el moneder</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>Canvia la contrasenya</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>Confirma l&apos;encriptació del moneder</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Esteu segur que voleu encriptar el vostre moneder?</translation>
    </message>
    <message>
        <location line="+9"/>
        <location line="+60"/>
        <source>Wallet encrypted</source>
        <translation>Moneder encriptat</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>IMPORTANT: Tota copia de seguretat que hàgiu realitzat hauria de ser reemplaçada pel, recentment generat, fitxer encriptat del moneder. Per motius de seguretat, les còpies de seguretat anteriors del fitxer de moneder no encriptat esdevindran inusables tan aviat com començar a utilitzar el nou moneder encriptat.</translation>
    </message>
    <message>
        <location line="+9"/>
        <location line="+7"/>
        <location line="+44"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>L&apos;encriptació del moneder ha fallat</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>L&apos;encriptació del moneder ha fallat per un error intern. El moneder no ha estat encriptat.</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+50"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Les contrasenyes introduïdes no coincideixen.</translation>
    </message>
    <message>
        <location line="-38"/>
        <source>Wallet unlock failed</source>
        <translation>El desbloqueig del moneder ha fallat</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+12"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La contrasenya introduïda per a desencriptar el moneder és incorrecta.</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>La desencriptació del moneder ha fallat</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>La contrasenya del moneder ha estat modificada correctament.</translation>
    </message>
    <message>
        <location line="+48"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Avís: Les lletres majúscules estan activades!</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+30"/>
        <source>Serves to disable the trivial sendmoney when OS account compromised. Provides no real security.</source>
        <translation>Serveix per desactivar l&apos;enviament trivial de diners quan el compte del sistema operatiu ha estat compromès. No ofereix seguretat real.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>For staking only</source>
        <translation>Només per a fer &quot;stake&quot;</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="-188"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Introdueixi tant l&apos;antiga com la nova contrasenya de moneder.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR COINS&lt;/b&gt;!</source>
        <translation>Avís: Si xifra el seu moneder i perd la contrasenya, podrà &lt;b&gt; PERDRE TOTES LES SEVES MONEDES &lt;/ b&gt;!</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Gridcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your coins from being stolen by malware infecting your computer.</source>
        <translation>Gridcoin tancarà ara per acabar el procés de xifrat. Recordeu que l&apos;encriptació del seu moneder no pot protegir completament les seves monedes de ser robades pel malware que pugui infectar al seu equip.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="+336"/>
        <source>Sign &amp;message...</source>
        <translation>Signa el &amp;missatge...</translation>
    </message>
    <message>
        <location line="-100"/>
        <source>&amp;Overview</source>
        <translation>&amp;Panorama general</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show general overview of wallet</source>
        <translation>Mostra el panorama general del moneder</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaccions</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>Cerca a l&apos;historial de transaccions</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>E&amp;xit</source>
        <translation>S&amp;urt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>Surt de l&apos;aplicació</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcions...</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Encripta el moneder...</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Canvia la contrasenya...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Canvia la contrasenya d&apos;encriptació del moneder</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Debug window</source>
        <translation>&amp;Finestra de depuració</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>Obre la consola de diagnòstic i depuració</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifica el missatge...</translation>
    </message>
    <message>
        <location line="-218"/>
        <source>Wallet</source>
        <translation>Moneder</translation>
    </message>
    <message>
        <location line="+122"/>
        <source>&amp;Send</source>
        <translation>&amp;Envia</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Receive</source>
        <translation>&amp;Rep</translation>
    </message>
    <message>
        <location line="+78"/>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Mostra / Amaga</translation>
    </message>
    <message>
        <location line="+78"/>
        <source>&amp;File</source>
        <translation>&amp;Fitxer</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>&amp;Settings</source>
        <translation>&amp;Configuració</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message numerus="yes">
        <location line="+276"/>
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>S&apos;ha processat %n bloc de l&apos;historial de transacció.</numerusform>
            <numerusform>S&apos;han processat %n blocs de l&apos;historial de transacció.</numerusform>
        </translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Up to date</source>
        <translation>Al dia</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Catching up...</source>
        <translation>S&apos;està posant al dia ...</translation>
    </message>
    <message>
        <location line="+222"/>
        <source>Sent transaction</source>
        <translation>Transacció enviada</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Incoming transaction</source>
        <translation>Transacció entrant</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>El moneder està &lt;b&gt;encriptat&lt;/b&gt; i actualment &lt;b&gt;bloquejat&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="-926"/>
        <source>Send coins to a Gridcoin address</source>
        <translation>Enviar monedes a una adreça Gridcoin</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Mostra la llista d&apos;adreces per rebre pagaments</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Edició de la llista d&apos;adreces i etiquetes emmagatzemades</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Block Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Block Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+4"/>
        <source>Web Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-1"/>
        <source>&amp;Web Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;GRC Chat Room</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>GRC Chatroom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;BOINC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Gridcoin rewards distributed computing with BOINC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+34"/>
        <source>&amp;New User Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Xifrar o desxifrar moneder</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Backup Wallet/Config...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Backup wallet/config to another location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Unlock Wallet...</source>
        <translation>&amp;Desbloquejar moneder</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Unlock wallet</source>
        <translation>Desbloquejar el moneder</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Lock Wallet</source>
        <translation>&amp;Bloquejar moneder</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Lock wallet</source>
        <translation>Bloquejar moneder</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportar les dades de la pestanya actual a un arxiu</translation>
    </message>
    <message numerus="yes">
        <location line="+380"/>
        <source>%n second(s) ago</source>
        <translation type="unfinished">
            <numerusform>fa %n segon</numerusform>
            <numerusform>fa %n segon</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n minute(s) ago</source>
        <translation type="unfinished">
            <numerusform>fa %n minut</numerusform>
            <numerusform>fa %n minut</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n hour(s) ago</source>
        <translation type="unfinished">
            <numerusform>fa %n hora</numerusform>
            <numerusform>fa %n hora</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s) ago</source>
        <translation type="unfinished">
            <numerusform>fa %n dia</numerusform>
            <numerusform>fa %n dia</numerusform>
        </translation>
    </message>
    <message>
        <location line="+169"/>
        <source>Please enter your BOINC E-mail address, or click &lt;Cancel&gt; to skip for now:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+21"/>
        <source>To get started with BOINC, run the BOINC client, choose projects, then populate the gridcoinresearch.conf file in %appdata%\GridcoinResearch with your BOINC e-mail address.  To run this wizard again, please delete the gridcoinresearch.conf file. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Attention! - BOINC Path Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4</source>
        <translation type="unfinished">Data: %1\nQuantitat %2\n Tipus: %3\n Adreça: %4\n {1
?} {2
?} {3
?} {4?}</translation>
    </message>
    <message>
        <location line="+446"/>
        <source>Staking.&lt;br&gt;Your weight is %1&lt;br&gt;Network weight is %2&lt;br&gt;&lt;b&gt;Estimated&lt;/b&gt; time to earn reward is %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Not staking; %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+26"/>
        <location line="+17"/>
        <location line="+9"/>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Scraper: waiting on wallet to sync.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Scraper: superblock not needed - inactive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Scraper: downloading and processing stats.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Scraper: Convergence achieved, date/time %1 UTC. 
Project(s) excluded: %2. 
Scrapers included: %3. 
Scraper(s) excluded: %4. 
Scraper(s) not publishing: %5.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Scraper: Convergence achieved, date/time %1 UTC. 
 Project(s) excluded: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Scraper: No convergence able to be achieved. Will retry in a few minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-1405"/>
        <source>Gridcoin</source>
        <translation>Gridcoin</translation>
    </message>
    <message>
        <location line="+190"/>
        <source>&amp;About Gridcoin</source>
        <translation>&amp;Sobre Gridcoin</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show information about Gridcoin</source>
        <translation>Mostra informació sobre Gridcoin</translation>
    </message>
    <message>
        <location line="+8"/>
        <location line="+582"/>
        <source>New User Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-639"/>
        <source>&amp;Voting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Voting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+51"/>
        <source>&amp;Diagnostics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Diagnostics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Modify configuration options for Gridcoin</source>
        <translation>Modificar les opcions de configuració per a Gridcoin</translation>
    </message>
    <message>
        <location line="+212"/>
        <location line="+9"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+69"/>
        <source>Gridcoin client</source>
        <translation>Client Gridcoin</translation>
    </message>
    <message>
        <location line="+83"/>
        <source>%1 active connection(s) to Gridcoin network</source>
        <translation type="unfinished">%1 conexió activa a la xarxa Gridcoin</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Last received block was generated %1.</source>
        <translation>El darrer bloc rebut s&apos;ha generat %1.</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>Aquesta transacció es troba sobre el límit de mida. Encara pot enviar-la amb una comisió de 1%, aquesta va als nodes que processen la seva transacció i ajuda a mantenir la xarxa. Vol pagar la quota?</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm transaction fee</source>
        <translation>Confirmeu comisió</translation>
    </message>
    <message>
        <location line="+85"/>
        <source>Created new Configuration File Successfully. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>New Account Created - Welcome Aboard!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>New User Wizard - Skipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+202"/>
        <location line="+15"/>
        <source>URI can not be parsed! This can be caused by an invalid Gridcoin address or malformed URI parameters.</source>
        <translation>l&apos;URI no es pot analitzar! Això pot ser causat per una adreça Gridcoin no vàlida o paràmetres URI malformats.</translation>
    </message>
    <message>
        <location line="-15"/>
        <location line="+15"/>
        <source>URI handling</source>
        <translation>Manejant URI</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&lt;b&gt;unlocked for staking only&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&lt;b&gt;fully unlocked&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Backup Wallet</source>
        <translation>Realitzar còpia de seguretat del moneder</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Dades del moneder (*.dat)</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+6"/>
        <source>Backup Failed</source>
        <translation>Còpia de seguretat fallida</translation>
    </message>
    <message>
        <location line="-6"/>
        <location line="+6"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>Hi ha un error al tractar de salvar les dades del seu moneder a la nova ubicació.</translation>
    </message>
    <message>
        <location line="-3"/>
        <source>Backup Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Config (*.conf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location line="+179"/>
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location line="-967"/>
        <source>&amp;Community</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoin.cpp" line="+176"/>
        <source>A fatal error occurred. Gridcoin can no longer continue safely and will quit.</source>
        <translation>S&apos;ha produït un error fatal. Gridcoin ja no pot continuar de forma segura i es tancarà.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+123"/>
        <source>Network Alert</source>
        <translation>Alerta de xarxa</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="+42"/>
        <source>Quantity:</source>
        <translation>Quantitat:</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>Amount:</source>
        <translation>Import:</translation>
    </message>
    <message>
        <location line="+62"/>
        <source>Fee:</source>
        <translation>Comissió:</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>After Fee:</source>
        <translation>Comissió posterior:</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Change:</source>
        <translation>Canvi:</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>(un)select all</source>
        <translation>(des)selecciona-ho tot</translation>
    </message>
    <message>
        <location line="+74"/>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirmations</source>
        <translation>Confirmacions</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed</source>
        <translation>Confirmat</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="+36"/>
        <source>Copy address</source>
        <translation>Copia l&apos;adreça</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etiqueta</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+26"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;import</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Copy transaction ID</source>
        <translation>Copia l&apos;ID de transacció</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Copy quantity</source>
        <translation>Copia la quantitat</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Copy fee</source>
        <translation>Copia la comissió</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy after fee</source>
        <translation>Copia la comissió posterior</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy bytes</source>
        <translation>Copia els bytes</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Copy change</source>
        <translation>Copia el canvi</translation>
    </message>
    <message>
        <location line="+481"/>
        <source>yes</source>
        <translation>sí</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <location line="+50"/>
        <location line="+63"/>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>change from %1 (%2)</source>
        <translation>canvia de %1 (%2)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>(change)</source>
        <translation>(canvia)</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="-406"/>
        <source>Coin Control</source>
        <translation>Opcions del control de monedes</translation>
    </message>
    <message>
        <location line="+113"/>
        <source>Priority:</source>
        <translation>Prioritat:</translation>
    </message>
    <message>
        <location line="+65"/>
        <source>Low Output:</source>
        <translation>Sortida baixa:</translation>
    </message>
    <message>
        <location line="+144"/>
        <source>Tree &amp;mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;List mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="-588"/>
        <source>Copy priority</source>
        <translation>Copiar prioritat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy low output</source>
        <translation>Copiar sortida baixa</translation>
    </message>
    <message>
        <location line="+318"/>
        <source>highest</source>
        <translation>El més alt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>high</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>medium-high</source>
        <translation>mig-alt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>medium</source>
        <translation>mig</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>low-medium</source>
        <translation>baix-mig</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>low</source>
        <translation>baix</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>lowest</source>
        <translation>el més baix</translation>
    </message>
    <message>
        <location line="+155"/>
        <source>DUST</source>
        <translation>POLS</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>This label turns red, if the transaction size is bigger than 10000 bytes.

 This means a fee of at least %1 per kb is required.

 Can vary +/- 1 Byte per input.</source>
        <translation>Aquesta etiqueta es tornarà vermell, si la mida de la transacció és més gran que 10000 bytes.

En aquest cas es requereix una comisió d&apos;almenys el 1% per kb. 

Pot variar + / - 1 Byte per entrada.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Transactions with higher priority get more likely into a block.

This label turns red, if the priority is smaller than &quot;medium&quot;.

 This means a fee of at least %1 per kb is required.</source>
        <translation>Les operacions amb més prioritat entren mes facilment a un bloc. 

Aquesta etiqueta es torna vermella, si la prioritat és menor que &quot;mitja&quot;.

En aquest cas es requereix una comisió d&apos;almenys el 1% per kb.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This label turns red, if any recipient receives an amount smaller than %1.

 This means a fee of at least %2 is required. 

 Amounts below 0.546 times the minimum relay fee are shown as DUST.</source>
        <translation>Aquesta etiqueta es torna vermella, si qualsevol beneficiari rep una quantitat inferior a 1%.

En aquest cas es requereix una comisió d&apos;almenys 2%.

Les quantitats inferiors a 0.546 vegades la quota mínima del relé es mostren com a POLS.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This label turns red, if the change is smaller than %1.

 This means a fee of at least %2 is required.</source>
        <translation>Aquesta etiqueta es torna vermella, si el canvi és menor que 1%.

En aquest cas es requereix una comisió d&apos;almenys 2%.</translation>
    </message>
</context>
<context>
    <name>DiagnosticsDialog</name>
    <message>
        <location filename="../forms/diagnosticsdialog.ui" line="+14"/>
        <location line="+210"/>
        <source>Diagnostics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-157"/>
        <source>Verify CPID is in Neural Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Verify BOINC path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Verify CPID has RAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Verify wallet is synced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Verify CPID is valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Find PrimaryCPID (Windows Only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Verify clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Verify connections to seeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Verify connections to network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Verify TCP port 32749</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Check client version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+48"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>Edita l&apos;adreça</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>&amp;Etiqueta</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>&amp;Address</source>
        <translation>&amp;Adreça</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+20"/>
        <source>New receiving address</source>
        <translation>Nova adreça de recepció</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>Nova adreça d&apos;enviament</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>Edita l&apos;adreça de recepció</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>Edita l&apos;adreça d&apos;enviament</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>L&apos;adreça introduïda «%1» ja és present a la llibreta d&apos;adreces.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Could not unlock wallet.</source>
        <translation>No s&apos;ha pogut desbloquejar el moneder.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>Ha fallat la generació d&apos;una clau nova.</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="-7"/>
        <source>The label associated with this address book entry</source>
        <translation>L&apos;etiqueta associada amb aquesta entrada de la llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>La direcció associada amb aquesta entrada de la llibreta d&apos;adreces. Només pot ser modificada per a l&apos;enviament d&apos;adreces.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="-15"/>
        <source>The entered address &quot;%1&quot; is not a valid Gridcoin address.</source>
        <translation>La direcció introduïda &quot;%1&quot; no és una adreça Gridcoin vàlida.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    <message>
        <location filename="../guiutil.cpp" line="+507"/>
        <source>version</source>
        <translation>versió</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>Ús:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>Opcions de la línia d&apos;ordres</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>Opcions de IU</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Definir llenguatge, per exemple &quot;de_DE&quot; (per defecte: Preferències locals de sistema)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>Iniciar minimitzat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Mostrar finestra de benvinguda a l&apos;inici (per defecte: 1)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Gridcoin-Qt</source>
        <translation>Gridcoin-Qt</translation>
    </message>
</context>
<context>
    <name>NewPollDialog</name>
    <message>
        <location filename="../votingdialog.cpp" line="+876"/>
        <location line="+96"/>
        <source>Create Poll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-81"/>
        <source>Title: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Days: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Question: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Discussion URL: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Share Type: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Add Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Remove Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Clear All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+36"/>
        <source>Creating poll failed! Title is missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Creating poll failed! Days value is missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Creating poll failed! Polls can not last longer than 180 days.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Creating poll failed! Question is missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Creating poll failed! URL is missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Creating poll failed! Answer is missing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Main</source>
        <translation>&amp;Principal</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>Reserved amount secures a balance in wallet that can be spendable at anytime. However reserve will secure utxo(s) of any size to respect this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+80"/>
        <source>&amp;Network</source>
        <translation>&amp;Xarxa</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Port obert amb &amp;UPnP</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port del proxy (per exemple 9050)</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>&amp;Window</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Mostra només la icona de la barra en minimitzar la finestra.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimitza a la barra d&apos;aplicacions en comptes de la barra de tasques</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimitza en tancar</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>&amp;Pantalla</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Llengua de la interfície d&apos;usuari:</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unitats per mostrar els imports en:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Selecciona la unitat de subdivisió per defecte per mostrar en la interfície quan s&apos;envien monedes.</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Whether to show coin control features or not.</source>
        <translation>Si voleu mostrar les funcions de control de monedes o no.</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;OK</source>
        <translation>&amp;D&apos;acord</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancel·la</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+55"/>
        <source>default</source>
        <translation>Per defecte</translation>
    </message>
    <message>
        <location line="+197"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>L&apos;adreça proxy introduïda és invalida.</translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="-455"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB. Fee 0.01 recommended.</source>
        <translation>Comisió opcional per kB que ajuda a assegurar-se que les seves transaccions es processen ràpidament. La majoria de les transaccions són 1 kB. Comisió d&apos;0.01 recomenada.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Pa&amp;y transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reserved amount does not participate in staking and is therefore spendable at any time.</source>
        <translation type="vanished">La quantitat reservada no participa en fer &quot;stake&quot; i per tant esta disponible en qualsevol moment.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Reser&amp;ve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start Gridcoin after logging in to the system.</source>
        <translation>Inicia automàticament Gridcoin després d&apos;entrar en el sistema.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start Gridcoin on system login</source>
        <translation>&amp;Iniciar Gridcoin amb l&apos;inici de sessió</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Detach block and address databases at shutdown. This means they can be moved to another data directory, but it slows down shutdown. The wallet is always detached.</source>
        <translation>Separeu el bloc i les bases de dades d&apos;adreces en apagar l&apos;equip. En aquest cas es pot moure a un altre directori de dades, però alenteix l&apos;apagada. El moneder està sempre separat.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Detach databases at shutdown</source>
        <translation>&amp;Separar bases de dades a l&apos;apagar l&apos;equip</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Automatically open the Gridcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Obrir automàticament el port de client Gridcoin en el router. Això només funciona quan el router és compatible amb UPnP i està habilitat.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Connect to the Gridcoin network through a SOCKS proxy (e.g. when connecting through Tor).</source>
        <translation>Connecteu-vos a la xarxa Gridcoin través d&apos;un proxy SOCKS (per exemple, quan es connecta a través de Tor).</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy:</source>
        <translation>&amp;Conectar a través d&apos;un proxy SOCKS:</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Pro&amp;xy IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+19"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>Adreça IP del servidor proxy (per exemple, 127.0.0.1)</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>SOCKS &amp;Version:</source>
        <translation>&amp;Versió de SOCKS:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>Versió SOCKS del proxy (per exemple 5)</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimitza en comptes de sortir de la aplicació al tancar la finestra. Quan aquesta opció està activa, la aplicació només es tancarà al seleccionar Sortir al menú.</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>The user interface language can be set here. This setting will take effect after restarting Gridcoin.</source>
        <translation>L&apos;idioma de la interfície d&apos;usuari es pot configurar aquí. Aquesta configuració s&apos;aplicarà després de reiniciar Gridcoin.</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Choose a stylesheet to change the look of the wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Whether to show Gridcoin addresses in the transaction list or not.</source>
        <translation>Per mostrar Gridcoin adreces a la llista de transaccions o no.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>&amp;Mostrar adreces al llistat de transaccions</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Display coin &amp;control features (advanced users only!)</source>
        <translation>Mostrar controls i característiques de la moneda (només per a experts!)</translation>
    </message>
    <message>
        <location line="+85"/>
        <source>&amp;Apply</source>
        <translation>&amp;Aplicar</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="-175"/>
        <source>Native</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+125"/>
        <location line="+9"/>
        <source>Warning</source>
        <translation>Avís</translation>
    </message>
    <message>
        <location line="-9"/>
        <location line="+9"/>
        <source>This setting will take effect after restarting Gridcoin.</source>
        <translation>Aquesta configuració s&apos;aplicarà després de reiniciar Gridcoin.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+32"/>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <location line="+88"/>
        <source>Available:</source>
        <translation>Disponible:</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Your current spendable balance</source>
        <translation>El balanç que podeu gastar actualment</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Immature:</source>
        <translation>Immadur:</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Your current total balance</source>
        <translation>El balanç total actual</translation>
    </message>
    <message>
        <location line="+100"/>
        <source>Coin Weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+128"/>
        <source>Recent transactions</source>
        <translation>Transaccions recents</translation>
    </message>
    <message>
        <location line="-392"/>
        <source>Wallet</source>
        <translation type="unfinished">Moneder</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+401"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Gridcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>La informació mostrada pot estar fora de data. El seu moneder es sincronitza automàticament amb la xarxa Gridcoin després d&apos;establir una connexió, però aquest procés no s&apos;ha completat encara.</translation>
    </message>
    <message>
        <location line="-339"/>
        <source>Stake</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Total number of coins that are staking, and do not yet count toward the current balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Unconfirmed</source>
        <translation type="unfinished">Sense confirmar</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Total de transaccions que encara no s&apos;han confirmat, i encara no compten per al balanç actual</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Total mined coins that have not yet matured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+88"/>
        <source>Blocks:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Difficulty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Net Weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+258"/>
        <source>Error Messages:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-234"/>
        <source>Magnitude:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>CPID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+203"/>
        <source>Current Poll:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+128"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>Fora de sincronia</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../bitcoin.cpp" line="+182"/>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="-461"/>
        <source>N/A</source>
        <translation type="unfinished">N/A</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>%1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+30"/>
        <source>%1 s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-24"/>
        <source>%1 B</source>
        <translation type="unfinished">%1 B</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 KB</source>
        <translation type="unfinished">%1 KB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 GB</source>
        <translation type="unfinished">%1 GB</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>%1 d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 h</source>
        <translation type="unfinished">%1 h</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 m</source>
        <translation type="unfinished">%1 m</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="+14"/>
        <source>QR Code Dialog</source>
        <translation>Diàleg de codi QR</translation>
    </message>
    <message>
        <location line="+62"/>
        <source>Request Payment</source>
        <translation>Sol·licitud de pagament</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Message:</source>
        <translation>Missatge:</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Amount:</source>
        <translation>Quantitat:</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Desa com ...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="+62"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Error codificant la URI en un codi QR.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>The entered amount is invalid, please check.</source>
        <translation>La quantitat introduïda no és vàlida, comproveu-ho si us plau.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI resultant massa llarga, intenta reduir el text per a la etiqueta / missatge</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Save QR Code</source>
        <translation>Desar codi QR</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Images (*.png)</source>
        <translation>Imatges PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+51"/>
        <location line="+43"/>
        <location line="+47"/>
        <location line="+16"/>
        <location line="+23"/>
        <location line="+16"/>
        <location line="+36"/>
        <location line="+16"/>
        <location line="+30"/>
        <location line="+58"/>
        <location line="+43"/>
        <location line="+42"/>
        <location line="+443"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+478"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location line="-1088"/>
        <source>Client version</source>
        <translation>Versió del client</translation>
    </message>
    <message>
        <location line="-135"/>
        <source>&amp;Information</source>
        <translation>&amp;Informació</translation>
    </message>
    <message>
        <location line="+291"/>
        <source>Startup time</source>
        <translation>&amp;Temps d&apos;inici</translation>
    </message>
    <message>
        <location line="-215"/>
        <source>Number of connections</source>
        <translation>Nombre de connexions</translation>
    </message>
    <message>
        <location line="+245"/>
        <source>Block chain</source>
        <translation>Cadena de blocs</translation>
    </message>
    <message>
        <location line="-58"/>
        <source>Current number of blocks</source>
        <translation>Nombre de blocs actuals</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Last block time</source>
        <translation>Últim temps de bloc</translation>
    </message>
    <message>
        <location line="+96"/>
        <source>&amp;Open</source>
        <translation>&amp;Obre</translation>
    </message>
    <message>
        <location line="+885"/>
        <source>&amp;Console</source>
        <translation>&amp;Consola</translation>
    </message>
    <message>
        <location line="-858"/>
        <source>&amp;Network Traffic</source>
        <translation>Trà&amp;nsit de la xarxa</translation>
    </message>
    <message>
        <location line="-167"/>
        <source>Qt version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+219"/>
        <source>&amp;Clear</source>
        <translation>Nete&amp;ja</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Totals</source>
        <translation>Totals</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>In:</source>
        <translation>Dins:</translation>
    </message>
    <message>
        <location line="+80"/>
        <source>Out:</source>
        <translation>Fora:</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>&amp;Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+67"/>
        <source>Banned peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+65"/>
        <location filename="../rpcconsole.cpp" line="+369"/>
        <source>Select a peer to view detailed information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Whitelisted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>User Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Services</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Starting Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Synced Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Synced Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Ban Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Connection Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Ping Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>The duration of a currently outstanding ping.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Ping Wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Min Ping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Time Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+124"/>
        <source>&amp;Scraper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-1081"/>
        <source>Debug log file</source>
        <translation>Fitxer de registre de depuració</translation>
    </message>
    <message>
        <location line="+1058"/>
        <source>Clear console</source>
        <translation>Neteja la consola</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-530"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+1"/>
        <location line="+1"/>
        <location line="+1"/>
        <source>Ban for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-3"/>
        <source>1 &amp;hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>1 &amp;day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>1 &amp;week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>1 &amp;year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+47"/>
        <source>&amp;Unban</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Utilitza les fletxes d&apos;amunt i avall per navegar per l&apos;historial, i &lt;b&gt;Ctrl-L&lt;\b&gt; per netejar la pantalla.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Escriviu &lt;b&gt;help&lt;\b&gt; per a obtenir un llistat de les ordres disponibles.</translation>
    </message>
    <message>
        <location line="+118"/>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>%1 m</source>
        <translation type="unfinished">%1 m</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>%1 h</source>
        <translation type="unfinished">%1 h</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 h %2 m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+125"/>
        <source>(node id: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>via %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+1"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+16"/>
        <location line="+6"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="-1335"/>
        <source>Gridcoin - Debug Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+335"/>
        <source>Boost version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Proof Of Research Difficulty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-247"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location line="+164"/>
        <source>Gridcoin Core:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-104"/>
        <source>Build date</source>
        <translation>Data de compilació</translation>
    </message>
    <message>
        <location line="+201"/>
        <source>Network:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-275"/>
        <source>On testnet</source>
        <translation>A testnet</translation>
    </message>
    <message>
        <location line="+348"/>
        <source>Estimated total blocks</source>
        <translation>Total estimat de blocs</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Open the Gridcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Obriu el fitxer de registre de depuració Gridcoin des del directori de dades actual. Això pot trigar uns segons en els arxius de registre de grans dimensions.</translation>
    </message>
    <message>
        <location line="-301"/>
        <source>Command-line options</source>
        <translation>Opcions de la línia d&apos;ordres</translation>
    </message>
    <message>
        <location line="-33"/>
        <source>Show the Gridcoin help message to get a list with possible Gridcoin command-line options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Show</source>
        <translation>&amp;Mostra</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>OpenSSL version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+177"/>
        <source>Client name</source>
        <translation>Nom del client</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-303"/>
        <source>Welcome to the Gridcoin RPC console! </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+177"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+6"/>
        <location line="+5"/>
        <location line="+5"/>
        <source>Send Coins</source>
        <translation>Envia monedes</translation>
    </message>
    <message>
        <location line="+67"/>
        <source>Coin Control Features</source>
        <translation>Característiques de control de les monedes</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Inputs...</source>
        <translation>Entrades...</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>automatically selected</source>
        <translation>seleccionat automàticament</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Insufficient funds!</source>
        <translation>Fons insuficients!</translation>
    </message>
    <message>
        <location line="+83"/>
        <source>Quantity:</source>
        <translation>Quantitat:</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <location line="+42"/>
        <source>Amount:</source>
        <translation>Import:</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Fee:</source>
        <translation>Comissió:</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>After Fee:</source>
        <translation>Comissió posterior:</translation>
    </message>
    <message>
        <location line="+188"/>
        <source>Send to multiple recipients at once</source>
        <translation>Envia a múltiples destinataris al mateix temps</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>Afegeix &amp;destinatari</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Clear &amp;All</source>
        <translation>Neteja-ho &amp;tot</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Balance:</source>
        <translation>Balanç:</translation>
    </message>
    <message>
        <location line="+47"/>
        <source>Confirm the send action</source>
        <translation>Confirma l&apos;acció d&apos;enviament</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>E&amp;nvia</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-165"/>
        <source>Copy quantity</source>
        <translation>Copia la quantitat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;import</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy fee</source>
        <translation>Copia la comissió</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy after fee</source>
        <translation>Copia la comissió posterior</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy bytes</source>
        <translation>Copia els bytes</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Copy change</source>
        <translation>Copia el canvi</translation>
    </message>
    <message>
        <location line="+98"/>
        <source>Confirm send coins</source>
        <translation>Confirma l&apos;enviament de monedes</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>L&apos;import a pagar ha de ser major que 0.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount exceeds your balance.</source>
        <translation>L&apos;import supera el vostre balanç.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>El total excedeix el vostre balanç quan s&apos;afegeix la comissió a la transacció %1.</translation>
    </message>
    <message>
        <location line="+280"/>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="-483"/>
        <location line="+26"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location line="+45"/>
        <location line="+68"/>
        <location line="+68"/>
        <location line="+23"/>
        <source>0.00 GRC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-149"/>
        <source>Priority:</source>
        <translation>Prioritat:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>medium</source>
        <translation>mig</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Low Output:</source>
        <translation>Sortida baixa:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Change</source>
        <translation>Canvi</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>custom change address</source>
        <translation>Adreça de canvi pròpia</translation>
    </message>
    <message>
        <location line="+141"/>
        <source>Remove all transaction fields</source>
        <translation>Traieu tots els camps de transacció</translation>
    </message>
    <message>
        <location line="+47"/>
        <source>123.456 GRC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-172"/>
        <source>Enter a Gridcoin address (e.g. S67nL4vELWwdDVzjgtEP4MxryarTZ9a8GB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-425"/>
        <source>Copy priority</source>
        <translation>Copiar prioritat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy low output</source>
        <translation>Copiar sortida baixa</translation>
    </message>
    <message>
        <location line="+93"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; a %2 (%3)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Esteu segur que voleu enviar %1?</translation>
    </message>
    <message>
        <location line="+0"/>
        <source> and </source>
        <translation>i</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>L&apos;adreça remetent no és vàlida, si us plau comprovi-la.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>S&apos;ha trobat una adreça duplicada, tan sols es pot enviar a cada adreça un cop per ordre de enviament.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: Transaction creation failed.</source>
        <translation>Error: La creació de transacció ha fallat.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected. This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: La transacció ha sigut rebutjada. Això pot passar si algunes de les monedes al moneder ja s&apos;han gastat, per exemple, si vostè utilitza una còpia del wallet.dat i les monedes han estat gastades a la cópia pero no s&apos;han marcat com a gastades aqui.</translation>
    </message>
    <message>
        <location line="+251"/>
        <source>WARNING: Invalid Gridcoin address</source>
        <translation>ADVERTÈNCIA: Direcció Gridcoin invàlida</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>WARNING: unknown change address</source>
        <translation>ADVERTÈNCIA: direcció de canvi desconeguda</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+155"/>
        <source>A&amp;mount:</source>
        <translation>Q&amp;uantitat:</translation>
    </message>
    <message>
        <location line="-106"/>
        <source>Pay &amp;To:</source>
        <translation>Paga &amp;a:</translation>
    </message>
    <message>
        <location line="+93"/>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>Alt+A</source>
        <translation>Alta+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>Enganxar adreça del porta-retalls</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Message:</source>
        <translation>Missatge:</translation>
    </message>
    <message>
        <location line="-89"/>
        <location line="+3"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Introduïu una etiqueta per a aquesta adreça per afegir-la a la llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>The address to send the payment to  (e.g. Sjz75uKHzUQJnSdzvpiigEGxseKkDhQToX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose address from address book</source>
        <translation>Trieu la direcció de la llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="+30"/>
        <source>Remove this recipient</source>
        <translation>Eliminar aquest destinatari</translation>
    </message>
    <message>
        <location line="+66"/>
        <source>Send Custom Message to a Gridcoin Recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-103"/>
        <source>Enter a Gridcoin address (e.g. S67nL4vELWwdDVzjgtEP4MxryarTZ9a8GB)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signatures - Signa / verifica un missatge</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signa el missatge</translation>
    </message>
    <message>
        <location line="+47"/>
        <location line="+198"/>
        <source>Alt+A</source>
        <translation>Alta+A</translation>
    </message>
    <message>
        <location line="-188"/>
        <source>Paste address from clipboard</source>
        <translation>Enganxar adreça del porta-retalls</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>Introduïu aquí el missatge que voleu signar</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copia la signatura actual al porta-retalls del sistema</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Sign &amp;Message</source>
        <translation>Signa el &amp;missatge</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all sign message fields</source>
        <translation>Neteja tots els camps de clau</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+147"/>
        <source>Clear &amp;All</source>
        <translation>Neteja-ho &amp;tot</translation>
    </message>
    <message>
        <location line="-94"/>
        <location line="+77"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica el missatge</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all verify message fields</source>
        <translation>Neteja tots els camps de verificació de missatge</translation>
    </message>
    <message>
        <location line="-192"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Feu clic a «Signa el missatge» per a generar una signatura</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+105"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>L&apos;adreça introduïda no és vàlida.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>Comproveu l&apos;adreça i torneu-ho a provar.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>L&apos;adreça introduïda no referencia a cap clau.</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>El desbloqueig del moneder ha estat cancelat.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>La clau privada per a la adreça introduïda no està disponible.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>La signatura del missatge ha fallat.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>Missatge signat.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>La signatura no s&apos;ha pogut descodificar.</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>Comproveu la signatura i torneu-ho a provar.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>La signatura no coincideix amb el resum del missatge.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>Ha fallat la verificació del missatge.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>Missatge verificat.</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="-88"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Pots signar missatges amb la teva adreça per provar que són teus. Sigues cautelòs al signar qualsevol cosa, ja que els atacs phising poden intentar confondre&apos;t per a que els hi signis amb la teva identitat. Tan sols signa als documents completament detallats amb els que hi estàs d&apos;acord.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with (e.g. Sjz75uKHzUQJnSdzvpiigEGxseKkDhQToX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+198"/>
        <source>Choose an address from the address book</source>
        <translation>Trieu una adreça de la llibreta d&apos;adreces</translation>
    </message>
    <message>
        <location line="-113"/>
        <source>Sign the message to prove you own this Gridcoin address</source>
        <translation>Signar un missatge per demostrar que és propietari d&apos;aquesta adreça Gridcoin</translation>
    </message>
    <message>
        <location line="+79"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Introdueixi l&apos;adreça signant, missatge (assegura&apos;t que copies salts de línia, espais, tabuladors, etc excactament tot el text) i la signatura a sota per verificar el missatge. Per evitar ser enganyat per un atac home-entre-mig, vés amb compte de no llegir més en la signatura del que hi ha al missatge signat mateix.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>The address the message was signed with (e.g. Sjz75uKHzUQJnSdzvpiigEGxseKkDhQToX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+47"/>
        <source>Verify the message to ensure it was signed with the specified Gridcoin address</source>
        <translation>Comproveu el missatge per assegurar-se que es va signar amb l&apos;adreça Gridcoin especificada.</translation>
    </message>
    <message>
        <location line="-239"/>
        <location line="+198"/>
        <source>Enter a Gridcoin address (e.g. S67nL4vELWwdDVzjgtEP4MxryarTZ9a8GB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Enter Gridcoin signature</source>
        <translation>Introduïu la signatura Gridcoin</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+38"/>
        <source>Open until %1</source>
        <translation>Obert fins %1</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>%1/offline</source>
        <translation>%1/fora de línia</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>%1/unconfirmed</source>
        <translation>%1/sense confirmar</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>%1 confirmations</source>
        <translation>%1 confirmacions</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, encara no ha estat emès correctement</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location line="+4"/>
        <location line="+5"/>
        <source>Source</source>
        <translation>Font</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>MINED - POS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - POR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - ORPHANED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>POS SIDE STAKE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>POR SIDE STAKE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+18"/>
        <source>From</source>
        <translation>De</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>unknown</source>
        <translation>desconegut</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+25"/>
        <location line="+63"/>
        <source>To</source>
        <translation>A</translation>
    </message>
    <message>
        <location line="-84"/>
        <location line="+3"/>
        <source>own address</source>
        <translation>adreça pròpia</translation>
    </message>
    <message>
        <location line="-3"/>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
    <message>
        <location line="+40"/>
        <location line="+14"/>
        <location line="+50"/>
        <location line="+20"/>
        <location line="+74"/>
        <source>Credit</source>
        <translation>Crèdit</translation>
    </message>
    <message>
        <location line="-152"/>
        <source>not accepted</source>
        <translation>no acceptat</translation>
    </message>
    <message>
        <location line="+48"/>
        <location line="+9"/>
        <location line="+16"/>
        <location line="+74"/>
        <source>Debit</source>
        <translation>Dèbit</translation>
    </message>
    <message>
        <location line="-83"/>
        <source>Transaction fee</source>
        <translation>Comissió de transacció</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Net amount</source>
        <translation>Import net</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Comment</source>
        <translation>Comentari</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>TX ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+3"/>
        <source>Block Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Transaction Stake Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Transaction Message Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Transaction Debits/Credits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Transaction Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Transaction Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>cert</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>fals</translation>
    </message>
    <message>
        <location line="-350"/>
        <source>conflicted</source>
        <translation>conflicte</translation>
    </message>
    <message numerus="yes">
        <location line="+55"/>
        <source>, broadcast through %n node(s)</source>
        <translation>
            <numerusform>, transmès a través de %n node</numerusform>
            <numerusform>, transmès a través de %n nodes</numerusform>
        </translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Generated in CoinBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location line="+89"/>
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>madura en %n bloc més</numerusform>
            <numerusform>madura en %n blocs més</numerusform>
        </translation>
    </message>
    <message>
        <location line="+119"/>
        <source>Gridcoin generated coins must mature 110 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location line="-282"/>
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform>Obert per a %n bloc més</numerusform>
            <numerusform>Obert per a %n blocs més</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+29"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Aquest panell mostra una descripció detallada de la transacció</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>Transaction details</source>
        <translation>Detall de la transacció</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Execute Contract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>C&amp;lose</source>
        <translation type="unfinished">&amp;Tanca</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+236"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Open until %1</source>
        <translation>Obert fins %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline</source>
        <translation>Fora de línia</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed</source>
        <translation>Sense confirmar</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmat (%1 confirmacions)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Conflicted</source>
        <translation>En conflicte</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Generated but not accepted</source>
        <translation>Generat però no acceptat</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Received with</source>
        <translation>Rebuda amb</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>Rebuda de</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>Enviada a</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>Pagament a un mateix</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>MINED - POS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - POR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - ORPHANED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>POS SIDE STAKE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>POR SIDE STAKE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>MINED - UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+54"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+190"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Estat de la transacció. Desplaceu-vos sobre aquest camp per mostrar el nombre de confirmacions.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Data i hora en que la transacció va ser rebuda.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>Tipus de transacció.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Import extret o afegit del balanç.</translation>
    </message>
    <message>
        <location line="-394"/>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Quantitat</translation>
    </message>
    <message numerus="yes">
        <location line="+52"/>
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>Obert per a %n bloc més</numerusform>
            <numerusform>Obert per a %n blocs més</numerusform>
        </translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Confirming (%1 of %2 recommended confirmations)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Immature (%1 confirmations, will be available after %2)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This block was not received by any other nodes&lt;br&gt; and will probably not be accepted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+316"/>
        <source>Destination address of transaction.</source>
        <translation>Adreça del destinatari de la transacció.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+55"/>
        <location line="+16"/>
        <source>All</source>
        <translation>Tot</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>Avui</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>Aquesta setmana</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>Aquest mes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>El mes passat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>Enguany</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>Rang...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>Rebuda amb</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>Enviada a</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>A un mateix</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mined</source>
        <translation>Minada</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>Altres</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Enter address or label to search</source>
        <translation>Introduïu una adreça o una etiqueta per cercar</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Min amount</source>
        <translation>Import mínim</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>Copia l&apos;adreça</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etiqueta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;import</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy transaction ID</source>
        <translation>Copia l&apos;ID de transacció</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>Editar etiqueta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>Mostra detalls de la transacció</translation>
    </message>
    <message>
        <location line="+145"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Fitxer separat per comes (*.csv)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Confirmed</source>
        <translation>Confirmat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+104"/>
        <source>Range:</source>
        <translation>Rang:</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <location line="-127"/>
        <source>Export Transaction Data</source>
        <translation>Exportació de dades de transaccions</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Amount</source>
        <translation>Quantitat</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error exporting</source>
        <translation>Error a l&apos;exportar</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>No s&apos;ha pogut escriure al fitxer %1.</translation>
    </message>
</context>
<context>
    <name>VotingChartDialog</name>
    <message>
        <location filename="../votingdialog.cpp" line="-405"/>
        <source>Poll Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Q: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Discussion URL: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+30"/>
        <source>Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-28"/>
        <source>Best Answer: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VotingDialog</name>
    <message>
        <location line="-313"/>
        <source>Active Polls (Right Click to Vote)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Filter: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Reload Polls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Load History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Create Poll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+46"/>
        <source>...loading data!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+26"/>
        <source>No polls !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VotingTableModel</name>
    <message>
        <location line="-382"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Expiration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Share Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-2"/>
        <source># Voters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Total Shares</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Best Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+126"/>
        <source>Row Number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Title.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Expiration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Share Type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Total Participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Total Shares.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Best Answer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VotingVoteDialog</name>
    <message>
        <location line="+533"/>
        <source>PlaceVote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Q: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Discussion URL: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Best Answer: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Vote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Vote failed! Select one or more items to vote.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+239"/>
        <source>Sending...</source>
        <translation>Enviant...</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="+225"/>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>Specify data directory</source>
        <translation>Especifica el directori de dades</translation>
    </message>
    <message>
        <location line="-121"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Connecta al node per obtenir les adreces de les connexions, i desconnecta</translation>
    </message>
    <message>
        <location line="+124"/>
        <source>Specify your own public address</source>
        <translation>Especifiqueu la vostra adreça pública</translation>
    </message>
    <message>
        <location line="-159"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accepta la línia d&apos;ordres i ordres JSON-RPC </translation>
    </message>
    <message>
        <location line="+135"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Executa en segon pla com a programa dimoni i accepta ordres</translation>
    </message>
    <message>
        <location line="-182"/>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Executa una ordre quan una transacció del moneder canviï (%s en cmd es canvia per TxID)</translation>
    </message>
    <message>
        <location line="+66"/>
        <source>Block creation options:</source>
        <translation>Opcions de la creació de blocs:</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Ha fallat escoltar a qualsevol port. Feu servir -listen=0 si voleu fer això.</translation>
    </message>
    <message>
        <location line="+94"/>
        <source>Specify configuration file (default: gridcoinresearch.conf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Specify wallet file (within data directory)</source>
        <translation>Especifica un fitxer de moneder (dins del directori de dades)</translation>
    </message>
    <message>
        <location line="-18"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Envia informació de traça/depuració a la consola en comptes del fitxer debug.log</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Redueix el fitxer debug.log durant l&apos;inici del client (per defecte: 1 quan no -debug)</translation>
    </message>
    <message>
        <location line="+30"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Nom d&apos;usuari per a connexions JSON-RPC</translation>
    </message>
    <message>
        <location line="-59"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Contrasenya per a connexions JSON-RPC</translation>
    </message>
    <message>
        <location line="-168"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Executa l&apos;ordre quan el millor bloc canviï (%s en cmd es reemplaça per un resum de bloc)</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permet consultes DNS per a -addnode, -seednode i -connect</translation>
    </message>
    <message>
        <location line="+81"/>
        <source>Loading addresses...</source>
        <translation>S&apos;estan carregant les adreces...</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Adreça -proxy invalida: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+98"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Xarxa desconeguda especificada a -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-100"/>
        <source>Insufficient funds</source>
        <translation>Balanç insuficient</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Loading block index...</source>
        <translation>S&apos;està carregant l&apos;índex de blocs...</translation>
    </message>
    <message>
        <location line="-86"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Afegeix un node per a connectar-s&apos;hi i intenta mantenir-hi la connexió oberta</translation>
    </message>
    <message>
        <location line="+87"/>
        <source>Loading wallet...</source>
        <translation>S&apos;està carregant el moneder...</translation>
    </message>
    <message>
        <location line="-66"/>
        <source>Cannot downgrade wallet</source>
        <translation>No es pot reduir la versió del moneder</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>No es pot escriure l&apos;adreça per defecte</translation>
    </message>
    <message>
        <location line="+103"/>
        <source>Rescanning...</source>
        <translation>S&apos;està reescanejant...</translation>
    </message>
    <message>
        <location line="-90"/>
        <source>Done loading</source>
        <translation>Ha acabat la càrrega</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location line="+111"/>
        <source>This help message</source>
        <translation>Aquest misatge d&apos;ajuda</translation>
    </message>
    <message>
        <location line="-7"/>
        <source>Specify pid file (default: gridcoind.pid)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Establir tamany de la memoria cau en megabytes (per defecte: 25)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set database disk log size in megabytes (default: 100)</source>
        <translation>Configurar la mida del registre en disc de la base de dades en megabytes (per defecte: 100)</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Especificar el temps limit per a un intent de connexió en milisegons (per defecte: 5000)</translation>
    </message>
    <message>
        <location line="-121"/>
        <source>Connect through socks proxy</source>
        <translation>Conectar a través d&apos;un proxy SOCKS</translation>
    </message>
    <message>
        <location line="+103"/>
        <source>Select the version of socks proxy to use (4-5, default: 5)</source>
        <translation>Seleccioneu la versió de proxy socks per utilitzar (4-5, per defecte: 5)</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Use proxy to reach tor hidden services (default: same as -proxy)</source>
        <translation>Utilitza proxy per arribar als serveis ocults de Tor (per defecte: la mateixa que -proxy)</translation>
    </message>
    <message>
        <location line="-94"/>
        <source>Listen for connections on &lt;port&gt; (default: 32749 or testnet: 32748)</source>
        <translation>Escoltar connexions en &lt;port&gt; (per defecte: 32749 o testnet: 32748)</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Mantenir com a molt &lt;n&gt; connexions a peers (per defecte: 125)</translation>
    </message>
    <message>
        <location line="-63"/>
        <source>Connect only to the specified node(s)</source>
        <translation>Connectar només al(s) node(s) especificats</translation>
    </message>
    <message>
        <location line="+84"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Només connectar als nodes de la xarxa &lt;net&gt; (IPv4, IPv6 o Tor)</translation>
    </message>
    <message>
        <location line="-75"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Descobrir la pròpia adreça IP (per defecte: 1 quan escoltant i no -externalip)</translation>
    </message>
    <message>
        <location line="-41"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Aceptar connexions d&apos;afora (per defecte: 1 si no -proxy o -connect)</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Bind to given address. Use [host]:port notation for IPv6</source>
        <translation>Enllaçar a l&apos;adreça donada. Utilitzeu la notació [host]:port per a IPv6</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Find peers using DNS lookup (default: 1)</source>
        <translation>Trobar companys utilitzant la recerca de DNS (per defecte: 1)</translation>
    </message>
    <message>
        <location line="-91"/>
        <source>Sync time with other nodes. Disable if time on your system is precise e.g. syncing with NTP (default: 1)</source>
        <translation>Sincronitzar el temps amb altres nodes. Desactivar si el temps al seu sistema és precís, per exemple, si fa ús de sincronització amb NTP (per defecte: 1)</translation>
    </message>
    <message>
        <location line="+194"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Límit per a desconectar connexions errònies (per defecte: 100)</translation>
    </message>
    <message>
        <location line="-204"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Nombre de segons abans de reconectar amb connexions errònies (per defecte: 86400)</translation>
    </message>
    <message>
        <location line="-56"/>
        <location line="+1"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source> days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+14"/>
        <source>A beacon was advertised less then 5 blocks ago. Please wait a full 5 blocks for your beacon to enter the chain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Specify p2p connection timeout in seconds. This option determines the amount of time a peer may be inactive before the connection to it is dropped. (minimum: 1, default: 45)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Unable to obtain superblock data before vote was made to calculate voting weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Add Beacon Contract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Add Foundation Poll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Add Poll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Add Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Alert: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Average Magnitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Block Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Block not in index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Block read failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Blocks Loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Blocks Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Boinc Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Boinc Reward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>CPID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Client Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Contract length for beacon is less then 256 in length. Size: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Current Neural Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete Beacon Contract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Difficulty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Eligible for Research Rewards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Entire balance reserved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Error: Wallet locked, unable to create transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Interest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Invalid amount for -peertimeout=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Invalid argument exception while parsing Transaction Message -&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid team</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Is Superblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Loading banlist...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Low difficulty!; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Magnitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Malformed CPID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Mida màxima del buffer de recepció per a cada connexió, &lt;n&gt;*1000 bytes (default: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Mida màxima del buffer d&apos;enviament per a cada connexió, &lt;n&gt;*1000 bytes (default: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Message Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Message Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Message Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Message</source>
        <translation type="unfinished">Missatge</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Miner: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Net averages not yet loaded; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Network Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Neural Contract Binary Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Neural Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>No Attached Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>No mature coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>No utxos available due to reserve balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Offline; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Print version and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Project email mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Research Age</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Share Type Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Share Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Text Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Text Rain Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Unable To Send Beacon! Unlock Wallet!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Unable to extract Share Type. Vote likely &gt; 6 months old</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Utilitza UPnP per a mapejar els ports d&apos;escolta (per defecte: 1 quan s&apos;escolta)</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Utilitza UPnP per a mapejar els ports d&apos;escolta (per defecte: 0)</translation>
    </message>
    <message>
        <location line="-118"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>Comisió per KB per a afegir a les transaccions que enviï</translation>
    </message>
    <message>
        <location line="-69"/>
        <source>When creating transactions, ignore inputs with value less than this (default: 0.01)</source>
        <translation>En crear transaccions, ignorar les entrades amb valor inferior a aquesta (per defecte: 0.01)</translation>
    </message>
    <message>
        <location line="+190"/>
        <source>Use the test network</source>
        <translation>Usar la xarxa de prova</translation>
    </message>
    <message>
        <location line="-61"/>
        <source>Output extra debugging information. Implies all other -debug* options</source>
        <translation>Sortida d&apos;informació de depuració extra. Implica totes les opcions de depuracó -debug*</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Output extra network debugging information</source>
        <translation>Sortida d&apos;informació de depuració de xarxa addicional</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Anteposar marca de temps a la sortida de depuració</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Enviar informació de traça/depuració al depurador</translation>
    </message>
    <message>
        <location line="-182"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 15715 or testnet: 25715)</source>
        <translation>Escoltar connexions JSON-RPC al port &lt;port&gt; (per defecte: 15715 o testnet: 25715)</translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Permetre connexions JSON-RPC d&apos;adreces IP específiques</translation>
    </message>
    <message>
        <location line="+129"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Enviar ordre al node en execució a &lt;ip&gt; (per defecte: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-8"/>
        <source>Require a confirmations for change (default: 0)</source>
        <translation>Requerir les confirmacions de canvi (per defecte: 0)</translation>
    </message>
    <message>
        <location line="-193"/>
        <source>Enforce transaction scripts to use canonical PUSH operators (default: 1)</source>
        <translation>Fer complir als scripts de transaccions d&apos;utilitzar operadors PUSH canòniques (per defecte: 1)</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Execute command when a relevant alert is received (%s in cmd is replaced by message)</source>
        <translation>
Executar una ordre quan es rep un avís rellevant (%s en cmd es substitueix per missatge)</translation>
    </message>
    <message>
        <location line="+210"/>
        <source>Staking Only - Investor Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Staking Only - No Eligible Research Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Actualitzar moneder a l&apos;últim format</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Establir límit de nombre de claus a &lt;n&gt; (per defecte: 100)</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Re-escanejar cadena de blocs en cerca de transaccions de moneder perdudes</translation>
    </message>
    <message>
        <location line="-119"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Intentar recuperar les claus privades d&apos;un arxiu wallet.dat corrupte</translation>
    </message>
    <message>
        <location line="-89"/>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+91"/>
        <source>Balance too low to create a smart contract.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Compute Neural Network Hashes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Error obtaining status.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Finding first applicable Research Project...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>How many blocks to check at startup (default: 2500, 0 = all)</source>
        <translation>Quants blocs s&apos;han de confirmar a l&apos;inici (per defecte: 2500, 0 = tots)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-6, default: 1)</source>
        <translation>Com és de minuciosa la verificació del bloc (0-6, per defecte: 1)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Imports blocks from external blk000?.dat file</source>
        <translation>Importar blocs desde l&apos;arxiu extern blk000?.dat</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Loading Network Averages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Loading Persisted Data Cache...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Maximum number of outbound connections (default: 8)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+14"/>
        <source>No coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>No current polls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Out of range exception while parsing Transaction Message -&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>POR Blocks Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Please wait for new user wizard to start...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Establir una mida mínima de bloc en bytes (per defecte: 0)</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Set maximum block size in bytes (default: 250000)</source>
        <translation>Establir una mida máxima de bloc en bytes (per defecte: 250000)</translation>
    </message>
    <message>
        <location line="-184"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</source>
        <translation>Establir la grandària màxima de les transaccions alta-prioritat/baixa-comisió en bytes (per defecte: 27000)</translation>
    </message>
    <message>
        <location line="+172"/>
        <source>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>Opcions SSL: (veure la Wiki de Bitcoin per a instruccions de configuració SSL)</translation>
    </message>
    <message>
        <location line="+42"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Utilitzar OpenSSL (https) per a connexions JSON-RPC</translation>
    </message>
    <message>
        <location line="-35"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Arxiu del certificat de servidor (per defecte: server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Clau privada del servidor (per defecte: server.pem)</translation>
    </message>
    <message>
        <location line="-65"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Quantitat invalida per a -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-100"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Advertència: el -paytxfee és molt elevat! Aquesta és la comissió de transacció que pagaràs quan enviis una transacció.</translation>
    </message>
    <message>
        <location line="+99"/>
        <source>Invalid amount for -mininput=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Quantitat invalida per a -mininput=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>Initialization sanity check failed. Gridcoin is shutting down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+113"/>
        <source>Wallet %s resides outside data directory %s.</source>
        <translation>El moneder %s resideix fora del directori de dades %s.</translation>
    </message>
    <message>
        <location line="-254"/>
        <source>Cannot obtain a lock on data directory %s.  Gridcoin is probably already running.</source>
        <translation>No es pot obtenir un bloqueig en el directori de dades %s. Gridcoin probablement ja estigui en funcionament.</translation>
    </message>
    <message>
        <location line="+252"/>
        <source>Verifying database integrity...</source>
        <translation>Comprovant la integritat de la base de dades ...</translation>
    </message>
    <message>
        <location line="-244"/>
        <source>Error initializing database environment %s! To recover, BACKUP THAT DIRECTORY, then remove everything from it except for wallet.dat.</source>
        <translation>Error en inicialitzar l&apos;entorn de base de dades %s! Per recuperar, FACI UNA COPIA DE SEGURETAT D&apos;AQUEST DIRECTORI, a continuació, retiri tot d&apos;ella excepte l&apos;arxiu wallet.dat.</translation>
    </message>
    <message>
        <location line="+48"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Advertència: L&apos;arxiu wallet.dat és corrupte, dades rescatades! L&apos;arxiu wallet.dat original ha estat desat com wallet.{estampa_temporal}.bak al directori %s; si el teu balanç o transaccions son incorrectes hauries de restaurar-lo de un backup.</translation>
    </message>
    <message>
        <location line="+197"/>
        <source>Vote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Wallet locked; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>L&apos;arxiu wallet.data és corrupte, el rescat de les dades ha fallat</translation>
    </message>
    <message>
        <location line="-19"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>S&apos;ha demanat una versió desconeguda de -socks proxy: %i</translation>
    </message>
    <message>
        <location line="-95"/>
        <source>Invalid -tor address: &apos;%s&apos;</source>
        <translation>Adreça -tor invalida: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-49"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>No es pot resoldre l&apos;adreça -bind: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>No es pot resoldre l&apos;adreça -externalip: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>Invalid amount for -reservebalance=&lt;amount&gt;</source>
        <translation>Quantitat invalida per a -reservebalance=&lt;amount&gt;</translation>
    </message>
    <message>
        <location line="-33"/>
        <source>Error loading blkindex.dat</source>
        <translation>Error carregant blkindex.dat</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Error carregant wallet.dat: Moneder corrupte</translation>
    </message>
    <message>
        <location line="-65"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Advertència: Error llegint l&apos;arxiu wallet.dat!! Totes les claus es llegeixen correctament, però hi ha dades de transaccions o entrades del llibre d&apos;adreces absents o bé son incorrectes.</translation>
    </message>
    <message>
        <location line="+66"/>
        <source>Error loading wallet.dat: Wallet requires newer version of Gridcoin</source>
        <translation>Error en carregar wallet.dat: El moneder requereix la versió més recent de Gridcoin</translation>
    </message>
    <message>
        <location line="+137"/>
        <source>Wallet needed to be rewritten: restart Gridcoin to complete</source>
        <translation>El moneder necessita ser reescrita: reiniciar Gridcoin per completar</translation>
    </message>
    <message>
        <location line="-139"/>
        <source>Error loading wallet.dat</source>
        <translation>Error carregant wallet.dat</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Importing blockchain data file.</source>
        <translation>Important fitxer de dades de la cadena de blocs</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Importing bootstrap blockchain data file.</source>
        <translation>Important fitxer de dades d&apos;arrencada de la cadena de blocs</translation>
    </message>
    <message>
        <location line="-13"/>
        <source>Error: could not start node</source>
        <translation>Error: no s&apos;ha pogut iniciar el node</translation>
    </message>
    <message>
        <location line="-84"/>
        <source>Unable to bind to %s on this computer. Gridcoin is probably already running.</source>
        <translation>No es pot enllaçar a %s en aquest equip. Gridcoin probablement ja estigui en funcionament.</translation>
    </message>
    <message>
        <location line="+196"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Impossible d&apos;unir %s a aquest ordinador (s&apos;ha retornat l&apos;error %d, %s)</translation>
    </message>
    <message>
        <location line="-115"/>
        <source>Error: Wallet locked, unable to create transaction  </source>
        <translation>Error: Moneder bloquejat, no es pot de crear la transacció</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error: Wallet unlocked for staking only, unable to create transaction.</source>
        <translation>Error: Cartera bloquejada nomès per a fer &quot;stake&quot;, no es pot de crear la transacció</translation>
    </message>
    <message>
        <location line="-110"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds  </source>
        <translation>Error: Aquesta transacció requereix una comisió d&apos;almenys %s degut a la seva quantitat, complexitat, o l&apos;ús dels fons rebuts recentment</translation>
    </message>
    <message>
        <location line="+107"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Error: La creació de transacció ha fallat.</translation>
    </message>
    <message>
        <location line="+88"/>
        <source>Sending...</source>
        <translation>Enviant...</translation>
    </message>
    <message>
        <location line="-199"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: La transacció ha sigut rebutjada. Això pot passar si algunes de les monedes al moneder ja s&apos;han gastat, per exemple, si vostè utilitza una còpia del wallet.dat i les monedes han estat gastades a la cópia pero no s&apos;han marcat com a gastades aqui.</translation>
    </message>
    <message>
        <location line="+139"/>
        <source>Invalid amount</source>
        <translation>Quanitat invalida</translation>
    </message>
    <message>
        <location line="-100"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Gridcoin will not work properly.</source>
        <translation>Avís: Comproveu que la data i hora de l&apos;equip siguin correctes! Si el seu rellotge és erroni Gridcoin no funcionarà correctament.</translation>
    </message>
    <message>
        <location line="+207"/>
        <source>Warning: Disk space is low!</source>
        <translation>Avís: L&apos;espai en disc és baix!</translation>
    </message>
    <message>
        <location line="-22"/>
        <source>To use the %s option</source>
        <translation>Utilitza la opció %s</translation>
    </message>
    <message>
        <location line="-259"/>
        <source>%s, you must set a rpcpassword in the configuration file:
 %s
It is recommended you use the following random password:
rpcuser=gridcoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Gridcoin Alert&quot; admin@foo.com
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+21"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>Ha sorgit un error al configurar el port RPC %u escoltant a IPv6, retrocedint a IPv4: %s</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Ha sorgit un error al configurar el port RPC %u escoltant a IPv4: %s</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Has de configurar el rpcpassword=&lt;password&gt; a l&apos;arxiu de configuració:\n %s\n Si l&apos;arxiu no existeix, crea&apos;l amb els permís owner-readable-only.</translation>
    </message>
    <message>
        <location line="+70"/>
        <source>Gridcoin version</source>
        <translation>versió Gridcoin</translation>
    </message>
    <message>
        <location line="+112"/>
        <source>Usage:</source>
        <translation>Ús:</translation>
    </message>
    <message>
        <location line="-39"/>
        <source>Send command to -server or gridcoind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-52"/>
        <source>List commands</source>
        <translation>Llista d&apos;ordres</translation>
    </message>
    <message>
        <location line="-22"/>
        <source>Get help for a command</source>
        <translation>Obtenir ajuda per a un ordre.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Gridcoin</source>
        <translation>Gridcoin</translation>
    </message>
</context>
</TS>
