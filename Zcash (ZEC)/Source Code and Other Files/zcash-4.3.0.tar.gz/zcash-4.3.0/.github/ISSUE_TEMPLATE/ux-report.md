---
name: UX report
about: Was zcashd hard to use? It's not you, it's us. We want to hear about it.
title: 'UX: '
labels: 'usability'
assignees: ''

---

<!-- Did zcashd not do what you expected?
Was it hard to figure out how to do something?
Could an error message be more helpful?
It's not you, it's us. We want to hear about it. -->

## What were you trying to do

## What happened
