Expectations for DNS Seed operators
====================================

This document has been relocated to https://zcash.readthedocs.io/en/latest/rtd_pages/dnsseed_policy.html

The source for this document is available at https://gitlab.com/zcash-docs/zcash-docs/blob/master/source/rtd_pages/dnsseed_policy.rst