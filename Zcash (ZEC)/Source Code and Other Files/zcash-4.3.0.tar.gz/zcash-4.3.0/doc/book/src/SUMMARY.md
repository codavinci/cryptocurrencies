# The zcashd Book

[zcashd](README.md)
- [Design](design.md)
  - [Chain state](design/chain-state.md)
  - ["Coins" view](design/coins-view.md)
