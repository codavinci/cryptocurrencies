Notable changes
===============

This release sets the EOS halt date to roughly July 14th, which was our original intention.

Changelog
=========

Sean Bowe (2):
      make-release.py: Versioning changes for 2.1.2-3.
      make-release.py: Updated manpages for 2.1.2-3.

