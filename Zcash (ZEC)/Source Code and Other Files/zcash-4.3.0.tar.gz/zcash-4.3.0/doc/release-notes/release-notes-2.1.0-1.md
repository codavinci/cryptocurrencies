Changelog
=========

Jack Grigg (2):
      make-release.py: Versioning changes for 2.1.0-1.
      make-release.py: Updated manpages for 2.1.0-1.

Sean Bowe (1):
      Fix of CVE-2017-18350

