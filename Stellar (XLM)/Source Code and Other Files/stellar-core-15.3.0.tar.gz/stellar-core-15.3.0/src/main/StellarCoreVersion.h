#pragma once

#include <string>

extern const std::string STELLAR_CORE_VERSION;
