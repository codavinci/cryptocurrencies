-- This migration file is intentionally empty and is a first starting point for
-- our migrations before we yet have a schema.

-- +migrate Up

-- +migrate Down

