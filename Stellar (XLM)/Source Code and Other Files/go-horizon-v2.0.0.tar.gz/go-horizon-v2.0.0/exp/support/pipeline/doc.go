// TODO explain here how to write wrappers to use without casting from `interface{}`.
package pipeline
