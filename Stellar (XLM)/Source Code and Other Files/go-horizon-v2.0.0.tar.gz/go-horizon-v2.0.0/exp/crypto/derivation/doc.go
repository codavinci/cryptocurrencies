// Package derivation provides functions for ed25519 key derivation as described in:
// https://github.com/satoshilabs/slips/blob/master/slip-0010.md
package derivation
