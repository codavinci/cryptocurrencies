package horizonclient

// version is the current version of the horizonclient.
// This is updated for every release.
const version = "2.1.0"
