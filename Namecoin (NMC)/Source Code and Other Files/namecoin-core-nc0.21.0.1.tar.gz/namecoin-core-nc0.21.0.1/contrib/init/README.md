Sample configuration files for:
```
SystemD: namecoind.service
Upstart: namecoind.conf
OpenRC:  namecoind.openrc
         namecoind.openrcconf
CentOS:  namecoind.init
macOS:   org.namecoin.namecoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
