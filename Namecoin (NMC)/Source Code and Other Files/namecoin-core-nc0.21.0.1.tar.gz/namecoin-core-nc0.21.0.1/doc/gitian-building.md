Gitian building
================

This file was moved to [the Namecoin Core documentation repository](https://github.com/namecoin/namecoin-core-docs/blob/master/gitian-building.md) at [https://github.com/namecoin/namecoin-core-docs](https://github.com/namecoin/namecoin-core-docs).
