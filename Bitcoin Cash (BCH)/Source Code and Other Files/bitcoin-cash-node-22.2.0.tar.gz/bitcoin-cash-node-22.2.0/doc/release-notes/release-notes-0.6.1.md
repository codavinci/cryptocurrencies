Bitcoin-Qt 0.6.1
================

Never released

