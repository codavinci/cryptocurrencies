Bitcoin 0.3.16
==============

Never released.
