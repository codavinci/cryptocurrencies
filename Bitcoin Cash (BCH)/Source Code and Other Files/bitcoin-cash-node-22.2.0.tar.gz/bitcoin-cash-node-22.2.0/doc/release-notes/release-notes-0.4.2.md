Bitcoin 0.4.2
=============

Never released or release notes were lost.
