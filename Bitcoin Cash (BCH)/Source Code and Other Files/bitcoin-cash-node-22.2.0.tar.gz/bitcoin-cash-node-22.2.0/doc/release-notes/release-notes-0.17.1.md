Bitcoin ABC 0.17.1
==================

Bitcoin ABC version 0.17.1 is now available from:

  <https://download.bitcoinabc.org/0.17.1/>

This release includes the following features and fixes:

 - Added CORS headers and pre-flight request support via RPC via required flag `-rpccorsdomain`.
 - Allow block candidates greater than 16MB to be submitted via RPC.
