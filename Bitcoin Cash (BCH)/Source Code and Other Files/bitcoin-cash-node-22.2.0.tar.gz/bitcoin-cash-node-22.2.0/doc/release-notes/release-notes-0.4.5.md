Bitcoin 0.4.5
=============

Never released or release notes were lost.
