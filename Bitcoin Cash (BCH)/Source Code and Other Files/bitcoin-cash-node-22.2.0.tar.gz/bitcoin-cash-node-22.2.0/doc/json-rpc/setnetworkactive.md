`setnetworkactive` JSON-RPC command
===================================

**`setnetworkactive state`**

```
Disable/enable all p2p network activity.
```

Arguments
---------

```
1. "state"        (boolean, required) true to enable networking, false to disable
```

***

*Bitcoin Cash Node Daemon version v22.2.0*
