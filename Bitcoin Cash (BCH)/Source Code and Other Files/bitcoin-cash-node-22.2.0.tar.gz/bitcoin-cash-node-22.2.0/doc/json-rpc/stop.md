`stop` JSON-RPC command
=======================

**`stop`**

```
Stop Bitcoin server.
```

***

*Bitcoin Cash Node Daemon version v22.2.0*
