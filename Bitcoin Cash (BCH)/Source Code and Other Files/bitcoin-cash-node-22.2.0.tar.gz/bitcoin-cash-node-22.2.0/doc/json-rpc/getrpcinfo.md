`getrpcinfo` JSON-RPC command
=============================

**`getrpcinfo`**

```
Returns details of the RPC server.
```

***

*Bitcoin Cash Node Daemon version v22.2.0*
