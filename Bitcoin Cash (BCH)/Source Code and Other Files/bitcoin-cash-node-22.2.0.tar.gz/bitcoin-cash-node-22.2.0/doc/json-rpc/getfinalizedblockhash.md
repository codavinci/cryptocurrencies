`getfinalizedblockhash` JSON-RPC command
========================================

**`getfinalizedblockhash`**

```
Returns the hash of the currently finalized block
```

Result
------

```
"hex"      (string) the block hash hex-encoded
```

***

*Bitcoin Cash Node Daemon version v22.2.0*
