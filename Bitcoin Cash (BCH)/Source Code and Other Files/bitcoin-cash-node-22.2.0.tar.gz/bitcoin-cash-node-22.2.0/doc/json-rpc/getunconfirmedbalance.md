`getunconfirmedbalance` JSON-RPC command
========================================

**`getunconfirmedbalance`**

```
Returns the server's total unconfirmed balance
```

***

*Bitcoin Cash Node Daemon version v22.2.0*
