<?php

/**
 * Interface for linters that can run once.
 */
interface ILintOnce {
}
