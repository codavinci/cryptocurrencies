<?php

phutil_register_library('arcanist-abc', __FILE__);
