#!/bin/sh

rm -rf install out build cache
mkdir build
mkdir out
mkdir install
mkdir -p cache/common
