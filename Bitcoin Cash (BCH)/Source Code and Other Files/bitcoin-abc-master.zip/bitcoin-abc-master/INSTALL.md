Building Bitcoin
================

See platform-specific instructions on building the various
elements of the Bitcoin ABC implementation of Bitcoin:
- [osx](doc/build-osx.md)
- [unix](doc/build-unix.md)
- [windows](doc/build-windows.md)