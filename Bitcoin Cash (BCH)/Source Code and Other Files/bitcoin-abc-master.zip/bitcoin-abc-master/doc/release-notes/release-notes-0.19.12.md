# Bitcoin ABC 0.19.12 Release Notes

Bitcoin ABC version 0.19.12 is now available from:

  <https://download.bitcoinabc.org/0.19.12/>

This release includes the following features and fixes:
  - Add the `getblockstats` RPC to get statistics on a block or a block range.
  - Logging improvements to reduce noisy network messages.
  - Logging added during wallet rescans.
  - Minor bug fixes, stability improvements, and typo corrections.
