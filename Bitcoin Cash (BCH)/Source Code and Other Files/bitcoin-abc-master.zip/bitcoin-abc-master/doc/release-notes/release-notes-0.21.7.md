# Bitcoin ABC 0.21.7 Release Notes

Bitcoin ABC version 0.21.7 is now available from:

  <https://download.bitcoinabc.org/0.21.7/>

This release includes the following features and fixes:
 - Improved performance of JSON RPC calls by ~25%
 - Minor stability improvements.
