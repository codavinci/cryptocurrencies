# Bitcoin ABC 0.21.1 Release Notes

Bitcoin ABC version 0.21.1 is now available from:

  <https://download.bitcoinabc.org/0.21.1/>

This release includes the following features and fixes:
  - Tweaked BIP9 behavior so that miners do not vote for IFP by default unintentionally.
