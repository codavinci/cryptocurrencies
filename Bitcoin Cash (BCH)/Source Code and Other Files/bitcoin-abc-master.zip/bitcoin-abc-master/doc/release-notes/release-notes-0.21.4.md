# Bitcoin ABC 0.21.4 Release Notes

Bitcoin ABC version 0.21.4 is now available from:

  <https://download.bitcoinabc.org/0.21.4/>

This release includes the following features and fixes:
 - The 32 bits Windows target is no longer supported. It will no longer be part
   of the release shipment. Users that are willing to build for 32 bits Windows
   should be aware that this will not be tested by the Bitcoin ABC team and be
   prepared to face issues.
