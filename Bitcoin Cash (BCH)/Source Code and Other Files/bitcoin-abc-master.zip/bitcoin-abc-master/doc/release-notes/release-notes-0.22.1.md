# Bitcoin ABC 0.22.1 Release Notes

Bitcoin ABC version 0.22.1 is now available from:

  <https://download.bitcoinabc.org/0.22.1/>

This release includes the following features and fixes:
 - Autotools build system is no longer supported and has been removed. Build
   instructions using cmake can be found in the `doc/build-*.md` documentation for
   your target platform.
