# Bitcoin ABC 0.22.7 Release Notes

Bitcoin ABC version 0.22.7 is now available from:

  <https://download.bitcoinabc.org/0.22.7/>

This release includes the following features and fixes:
 - Minor stability improvements.
