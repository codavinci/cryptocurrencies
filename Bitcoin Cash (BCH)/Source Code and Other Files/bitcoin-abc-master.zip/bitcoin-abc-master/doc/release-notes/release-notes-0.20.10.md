# Bitcoin ABC 0.20.10 Release Notes

Bitcoin ABC version 0.20.10 is now available from:

  <https://download.bitcoinabc.org/0.20.10/>

This release includes the following features and fixes:
 - Remove deprecated "startingpriority" and "currentpriority" from
   `getrawmempool`, `getmempoolancestors`, `getmempooldescendants` and
   `getmempoolentry` RPC.
