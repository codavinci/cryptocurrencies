# Bitcoin ABC 0.19.5 Release Notes

Bitcoin ABC version 0.19.5 is now available from:

  <https://download.bitcoinabc.org/0.19.5/>

This release includes the following features and fixes:
 - Deprecated the `-reserveChangeKey` option for `fundrawtransaction` wallet rpc command.
 - Fixed a bug where specifying the `-stopatheight` option would not stop at the correct height.
 - Minor stability fixes.
