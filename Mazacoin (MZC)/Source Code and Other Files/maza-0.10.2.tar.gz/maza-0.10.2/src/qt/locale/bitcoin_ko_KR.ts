<TS language="ko_KR" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>새 주소 만들기</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>새 항목(N)</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>현재 선택한 주소를 시스템 클립보드로 복사하기</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>복사</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>닫기 (L)</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>계좌 복사(&amp;C)</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>현재 목록에 선택한 주소 삭제</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>현재 탭에 있는 데이터를 파일로 내보내기</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;내보내기</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;삭제</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>코인을 보내실 주소를 선택하세요</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>코인을 받으실 주소를 선택하세요</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>선택하기 (H)</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>보내는 주소들</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>받은 주소들</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>비트코인을 받는 계좌 주소입니다. 코인을 보내기 전에 잔고와 받는 주소를 항상 확인하세요.</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>비트코인을 받을 수 있는 계좌 주소입니다. 매 거래마다 새로운 주소 사용을 권장합니다. </translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>표 복사</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>편집&amp;</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>주소 목록 내보내기</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>각각의 파일에 쉼표하기(*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>내보내기 실패</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>표</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>주소</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(표 없음)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>암호문 대화상자</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>암호 입력하기</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>새로운 암호</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>새 암호 반복</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>지갑 암호화</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>이 작업을 실행하려면 사용자 지갑의 암호가 필요합니다.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>지갑 열기</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>이 작업은 지갑을 해독하기 위해 사용자 지갑의 암호가 필요합니다.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>지갑 해독</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>암호 변경</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>지갑의 예전 암호와 새로운 암호를 입력</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>지갑의 암호화를 확정</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>경고: 만약 암호화된 지갑의 비밀번호를 잃어버릴 경우, 모든 비트코인들을 잃어버릴 수 있습니다!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>지갑 암호화를 허용하시겠습니까?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>중요: 본인 지갑파일에서 만든 예전 백업들은 새로 생성한 암화화된 지갑 파일로 교체됩니다. 보안상 이유로 이전에 암호화 하지 않은 지갑 파일 백업은 사용할 수 없게 되니 빠른 시일 내로 새로 암화화된 지갑을 사용하시기 바랍니다.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>경고: 캡스록 키가 켜져있습니다!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>지갑 암호화 완료</translation>
    </message>
    <message>
        <source>Bitcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation>암호화 처리 과정을 끝내기 위해 비트코인을 종료합니다. 지갑 암호화는 컴퓨터로의 멀웨어 감염으로 인한 비트코인 도난을 완전히 방지할 수 없음을 기억하세요.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>지갑 암호화 실패</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>지갑 암호화는 내부 에러로 인해 실패했습니다.  당신의 지갑은 암호화 되지 않았습니다.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>지정한 암호가 일치하지 않습니다.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>지갑을 열지 못했습니다.</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>지갑 해독을 위한 암호가 틀렸습니다.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>지갑 해독에 실패하였습니다.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>지갑 비밀번호가 성공적으로 변경되었습니다.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>메시지 서명&amp;...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>네트워크와 동기화중...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;개요</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>노드</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>지갑의 일반적 개요를 보여줍니다.</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;거래</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>거래내역을 검색합니다.</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>나가기(&amp;X)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>적용 중단</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Qt 정보(&amp;Q)</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Qt 정보를 표시합니다</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;옵션</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>지갑 암호화&amp;...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>지갑 백업&amp;...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>암호문 변경&amp;...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;주소 보내는 중</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp; 주소 받는 중</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>URI&amp;열기...</translation>
    </message>
    <message>
        <source>Bitcoin Core client</source>
        <translation>비트코인 코어 클라이언트</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>디스크에서 블록 가져오는 중...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>디스크에서 블록 다시 색인중...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>비트코인 주소로 코인 전송</translation>
    </message>
    <message>
        <source>Modify configuration options for Bitcoin</source>
        <translation>비트코인 설정 옵션 수정</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>지갑을 다른장소에 백업</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>지갑 암호화에 사용되는 암호를 변경합니다</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>디버그 창&amp;</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>디버깅 및 진단 콘솔을 엽니다</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>메시지 확인&amp;...</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>비트코인</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>지갑</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>보내기(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>받기(&amp;R)</translation>
    </message>
    <message>
        <source>Show information about Bitcoin Core</source>
        <translation>비트코인 코어에 관한 정보입니다.</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>보이기/숨기기(&amp;S)</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>주 창 보이기 또는 숨기기</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>소유 지갑 개인키 암호화</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>지갑 주소가 본인 소유인지 증명하기 위해 비트코인 주소에 서명할 수 있습니다.</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>비트코인 주소의 전자 서명 확인을 위해 첨부된 메시지가 있을 경우 이를 검증할 수 있습니다.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;파일</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;설정</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;도움말</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>툴바 색인표</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>비트코인 코어</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation>지불 요청하기 (QR코드와 비트코인이 생성됩니다: URIs)</translation>
    </message>
    <message>
        <source>&amp;About Bitcoin Core</source>
        <translation>&amp;비트코인 코어 소개</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>한번 이상 사용된 보내는 주소와 주소 제목의 목록을 보여줍니다.</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>한번 이상 사용된 받는 주소와 주소 제목의 목록을 보여줍니다.</translation>
    </message>
    <message>
        <source>Open a bitcoin: URI or payment request</source>
        <translation>비트코인: URI 또는 지불요청 열기</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>명령어-라인 옵션</translation>
    </message>
    <message>
        <source>Show the Bitcoin Core help message to get a list with possible Bitcoin command-line options</source>
        <translation>사용할 수 있는 비트코인 명령어 옵션 목록을 가져오기 위해 Bitcoin-Qt 도움말 메시지를 표시합니다.</translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>사용 가능한 블록이 없습니다...</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n시간</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n일</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n주</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 그리고 %2</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 뒤에</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>최근에 받은 블록은 %1 전에 생성되었습니다.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>이 후의 거래들은 아직 보이지 않을 것입니다.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>오류</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>경고</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>정보</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>현재까지</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>블록 따라잡기...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>거래 보내기</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>들어오고 있는 거래</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>날짜: %1
거래액: %2
형식: %3
주소: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>지갑이 암호화 되었고 현재 차단해제 되었습니다</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>지갑이 암호화 되었고 현재 잠겨져 있습니다</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>네트워크 경고</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>수량:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>바이트:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>거래량:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>우선순위:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>수수료:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>더스트:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>수수료 이후:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>체인지:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>모두 선택(하지 않음)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>트리 모드</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>리스트 모드</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>거래량</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>날짜</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>확인</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>확인됨</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>우선순위</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>주소 복사하기</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>표 복사하기</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>거래량 복사</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>거래 아이디 복사</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>비트코인이 사용되지 않은 주소를 잠금 처리합니다.</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>비트코인이 사용되지 않은 주소를 잠금 해제합니다. </translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>수량 복사</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>수수료 복사</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>수수료 이후 복사</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>bytes 복사</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>우선도 복사</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>아주 높음</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>보다 높음</translation>
    </message>
    <message>
        <source>high</source>
        <translation>높음</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>약간 높음</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>보통</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>약간 낮음</translation>
    </message>
    <message>
        <source>low</source>
        <translation>낮음</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>보다 낮음</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>아주 낮음</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 잠금)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>예</translation>
    </message>
    <message>
        <source>no</source>
        <translation>아니요</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>만약 거래 양이 1000bytes 보다 크면 제목이 빨간색으로 변합니다</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>이 의미는 수수료가 최소한 %1 per 키로바이트 필요합니다</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>우선 순위가 높은 거래의 경우 블럭에 포함될 가능성이 더 많습니다.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>우선권이 중간보다 작으면 제목이 빨간색으로 변합니다. </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(표 없음)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>~로부터 변경 %1 (%2)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>주소 편집</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;표</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>현재 선택된 주소 필드의 제목입니다. </translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;주소</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>새로 받는 주소</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>새로 보내는 주소</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>받는 주소 편집</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>보내는 주소 편집</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>입력된 주소는"%1" 이미 주소록에 있습니다.</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Bitcoin address.</source>
        <translation>입력한 "%1" 주소는 올바른 비트코인 주소가 아닙니다.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>지갑을 열 수 없습니다.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>새로운 키 생성이 실패하였습니다</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>새로운 데이터 폴더가 생성됩니다.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>폴더가 이미 존재합니다. 새로운 폴더 생성을 원한다면 %1 명령어를 추가하세요. </translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>경로가 이미 존재합니다. 그리고 그것은 폴더가 아닙니다.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>데이터 폴더를 여기 생성할 수 없습니다.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>비트코인 코어</translation>
    </message>
    <message>
        <source>version</source>
        <translation>버전</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-비트)</translation>
    </message>
    <message>
        <source>About Bitcoin Core</source>
        <translation>비트코인 코어 소개</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>명령줄 옵션</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>사용법:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>명령줄 옵션</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI 옵션</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>"de_DE"와 같이 언어를 설정하십시오 (기본값: 시스템 로캘)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>최소화 상태에서 시작</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>지불 요청을 위해 SSL 최상위 인증을 설정합니다. (기본값: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>시작시 시작 화면 표시 (기본값: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>파일목록을 선택하여 시작하시오(기본값: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>환영합니다</translation>
    </message>
    <message>
        <source>Welcome to Bitcoin Core.</source>
        <translation>비트코인 코어에 오신것을 환영합니.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Bitcoin Core will store its data.</source>
        <translation>프로그램이 처음으로 실행되고 있습니다. 비트코인 코어가 어디에 데이터를 저장할지 선택할 수 있습니다. </translation>
    </message>
    <message>
        <source>Bitcoin Core will download and store a copy of the Bitcoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>비트코인 코어가 블럭체인의 복사본을 다운로드 저장합니다. 적어도 %1GB의 데이터가 이 폴더에 저장되며 시간이 경과할수록 점차 증가합니다. 그리고 지갑 또한 이 폴더에 저장됩니다. </translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>기본 데이터 폴더를 사용하기</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>커스텀 데이터 폴더 사용:</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>비트코인 코어</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>오류</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI 열기</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>지급 요청 URI 또는 파일 열기</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>지불 요청 파일을 선택하세요</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>지불 요청 파일을 열기 위해서 선택하세요</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>선택들</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>메인(&amp;M)</translation>
    </message>
    <message>
        <source>Automatically start Bitcoin after logging in to the system.</source>
        <translation>시스템 로그인후에 비트코인을 자동으로 시작합니다.</translation>
    </message>
    <message>
        <source>&amp;Start Bitcoin on system login</source>
        <translation>시스템 로그인시 비트코인 시작(&amp;S)</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>데이터베이스 캐시 크기</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>메가바이트</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>스크립트 인증 쓰레드의 개수</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>외부로부터의 연결을 승인합니다.</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>연결 요청을 허용합니다.</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>프록시 아이피 주소(예. IPv4:127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>제 3자 거래 URLs</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>명령어 라인 옵션을 활성화해서 옵션을 우회하시오</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>모든 클라이언트 옵션을 기본값으로 재설정</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>옵션 재설정(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>네트워크(&amp;N)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>지갑</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>전문가</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>코인 상세 제어기능을 활성화합니다 - &amp;C</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;확인되지 않은 돈을 쓰다</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>라우터의 비트코인 클라이언트 포트를 자동으로 엽니다. 라우터에서 UPnP를 지원하고 활성화 했을 경우에만 동작합니다.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>사용중인 UPnP 포트 매핑(&amp;U)</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>프록시 IP(&amp;I):</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>포트(&amp;P):</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>프록시의 포트번호입니다(예: 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>창(&amp;W)</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>창을 최소화 하면 트레이에 아이콘만 표시합니다.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>작업 표시줄 대신 트레이로 최소화(&amp;M)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>창을 닫으면 프로그램에서 나가지 않고 최소화합니다. 이 옵션을 활성화하면, 프로그램은 메뉴에서 나가기를 선택한 후에만 닫힙니다.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>닫을때 최소화(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>표시(&amp;D)</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>사용자 인터페이스 언어(&amp;L):</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Bitcoin.</source>
        <translation>사용자 인터페이스 언어를 여기서 설정할 수 있습니다. 이 설정은 비트코인을 다시 시작할때 적용됩니다.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>거래액을 표시할 단위(&amp;U):</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>인터페이스에 표시하고 코인을 보낼때 사용할 기본 최소화 단위를 선택하십시오.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>코인 상세 제어기능에 대한 표시 여부를 선택할 수 있습니다.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>확인(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>취소(&amp;C)</translation>
    </message>
    <message>
        <source>default</source>
        <translation>기본값</translation>
    </message>
    <message>
        <source>none</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>옵션 초기화를 확인</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>변경 사항을 적용하기 위해서는 프로그램이 종료 후 재시작되어야 합니다.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>클라이언트가 종료됩니다, 계속 진행하시겠습니까?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>이 변경 사항 적용을 위해 프로그램 재시작이 필요합니다. </translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>지정한 프록시 주소가 잘못되었습니다.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>유형</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>표시한 정보가 오래된 것 같습니다. 비트코인 네트워크에 연결하고 난 다음에 지갑을 자동으로 동기화 하지만, 아직 과정이 끝나지는 않았습니다.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>모니터링 지갑:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>사용 가능</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>당신의 현재 사용 가능한 잔액</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>미확정</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>전체 거래들은 아직 확인되지 않았고, 그리고 현재 잔액에 아직 반영되지 않았습니다.</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>아직 사용 불가능:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>아직 사용 가능하지 않은 채굴된 잔액</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>총액:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>당신의 현재 총액</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>모니터링 지갑의 현재 잔액</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>동기화 필요</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI 조작중</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>잘못된 지불 주소입니다 %1</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>요청한 금액 %1의 양이 너무 적습니다. (스팸성 거래로 간주)</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>지불 요청 애러</translation>
    </message>
    <message>
        <source>Cannot start bitcoin: click-to-pay handler</source>
        <translation>비트코인을 시작할 수 없습니다: 지급제어기를 클릭하시오</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>대금 청구서의 URL이 올바르지 않습니다: %1</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>지불이 파일 처리를 요청합니다</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>임의로 변경한 결제 스크립트 기반의 대금 청구서 양식은 검증되기 전까지는 지원되지 않습니다.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>%1 으로부터의 환불</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>%1과 소통하는데 애러: %2</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>서버로 부터 반응이 없습니다 %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>지불이 승인됨</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>네트워크 요청 애러</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>거래량</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>없음</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>이미지 저장(&amp;S)...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>이미지 복사(&amp;C)</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR코드 저장</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG 이미지(*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>클라이언트 이름</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>클라이언트 버전</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>정보</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>디버그 창</translation>
    </message>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>오픈SSL 버전을 사용합니다</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>시작 시간</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>네트워크</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>연결 수</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>블럭 체인</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>현재 블럭 수</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>최종 블럭 시각</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>열기(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>콘솔(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;네트워크 트래픽</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;지우기</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>총액</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>In:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Out:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>빌드 날짜</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>로그 파일 디버그</translation>
    </message>
    <message>
        <source>Open the Bitcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>비트코인 디버그 로그파일을 현재 데이터 폴더에서 여십시요. 용량이 큰 로그 파일들은 몇 초가 걸릴 수 있습니다.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>콘솔 초기화</translation>
    </message>
    <message>
        <source>Welcome to the Bitcoin RPC console.</source>
        <translation>비트코인 RPC 콘솔에 오신걸 환영합니다</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>기록을 찾아보려면 위 아래 화살표 키를, 화면을 지우려면 &lt;b&gt;Ctrl-L&lt;/b&gt;키를 사용하십시오.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>사용할 수 있는 명령을 둘러보려면 &lt;b&gt;help&lt;/b&gt;를 입력하십시오.</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;거래량:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>표:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;메시지:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>이전에 사용된 수취용 주소를 사용할려고 합니다. 주소의 재사용은 보안과 개인정보 보호 측면에서 문제를 초래할 수 있습니다. 이전 지불 요청을 재생성하는 경우가 아니라면 주소 재사용을 권하지 않습니다.  </translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>현재의 수취용 주소를 재사용합니다만 권장하지는 않습니다. (R&amp;)</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>임의의 라벨이 새로운 받기 주소와 결합</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>지급을 요청하기 위해 아래 형식을 사용하세요. 입력값은 &lt;b&gt;선택 사항&lt;/b&gt; 입니다.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>요청할 금액 입력칸으로 선택 사항입니다. 빈 칸으로 두거나 특정 금액이 필요하지 않는 경우 0을 입력하세요. </translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>양식의 모든 필드를 지웁니다</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>지우기</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>지출기록 확인</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>지불 요청(&amp;R)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>보기</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>목록에서 삭제할 항목을 선택하시오</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>표 복사하기</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>메시지 복사</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>거래량 복사</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR 코드</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>URI 복사(&amp;U)</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>주소 복사(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>이미지 저장(&amp;S)...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>%1에 지불을 요청했습니다</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>지불 정보</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>주소</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>거래량</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>표</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>메시지</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI 결과가 너무 길음, 표/메세지의 글을 줄이도록 하세요.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>QR코드 인코딩 오류</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>날짜</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>표</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>메시지</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>거래량</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(표 없음)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(메세지가 없습니다)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(거래량 없음)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>코인들 보내기</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>코인 컨트롤 기능들</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>입력...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>자동 선택</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>자금이 부족합니다!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>수량:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>바이트:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>거래량:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>우선순위:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>수수료:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>수수료 이후:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>체인지:</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>주소변경</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>다수의 수령인들에게 한번에 보내기</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>수령인 추가하기</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>양식의 모든 필드를 지웁니다</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>더스트:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>모두 지우기(&amp;A)</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>잔액:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>전송 기능 확인</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>보내기(&amp;E)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>코인 전송을 확인</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1을(를) %2(으)로</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>수량 복사</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>거래량 복사</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>수수료 복사</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>수수료 이후 복사</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>bytes 복사</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>우선도 복사</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>총 액수 %1(=%2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>또는</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>수령인 주소가 정확하지 않습니다. 재확인 바랍니다</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>지불하는 금액은 0 보다 커야 합니다.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>잔고를 초과하였습니다.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>%1 의 거래수수료를 포함하면 잔고를 초과합니다.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>두개 이상의 주소입니다. 한번에 하나의 주소에만 작업할 수 있습니다.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>거래를 생성하는 것을 실패하였습니다</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>거래가 거부되었습니다. 몇몇 코인들이 지갑에서 이미 사용된 경우, 예를 들어 코인을 이미 사용한  wallet.dat를 복사해서 사용한 경우 지금 지갑에 기록이 안되있어 이런 일이 생길 수 있습니다.</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin address</source>
        <translation>경고: 잘못된 비트코인주소입니다</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(표 없음)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>경고: 알려지지 않은 주소변경입니다</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>정말로 보내시겠습니까?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>거래 수수료로 추가됨</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>금액:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>지급&amp;수신:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>당신의 주소록에 이 주소를 추가하기 위하여 표를 입역하세요 </translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>표:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>이전에 사용한 주소를 선택하십시오</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>평균지급입니다</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>클립보드로 부터 주소를 붙이세요</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>항목을 지우시오</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>메시지:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>지급 확인요청입니다.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>사용된 주소 목록에 새 주소를 추가하기 위해 제목을 입력합니다. </translation>
    </message>
    <message>
        <source>A message that was attached to the bitcoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin network.</source>
        <translation>비트코인에 첨부된 메시지: 참고용으로 거래와 함께 저장될 URI. 메모: 이 메시지는 비트코인 네트워크로 전송되지 않습니다.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>지급요청 미확인입니다</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>송금할 대상 : </translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>메모:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Bitcoin Core is shutting down...</source>
        <translation>비트코인코어가 닫아지고 있습니다</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>창이 사라지기 전까지 컴퓨터를 끄지마시오.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>서명 - 싸인 / 메시지 확인</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>메시지 서명(&amp;S)</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>여러분 자신을 증명하기 위해 주소를 첨가하고 섬여할 수 있습니다. 피싱 공격으로 말미암아 여러분의 서명을 통해 속아 넘어가게 할 수 있으므로, 서명하지 않은 어떤 모호한 요소든 주의하십시오. 동의하는 완전 무결한 조항에만 서명하십시오.</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>이전에 사용한 주소를 선택하십시오</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>클립보드로 부터 주소를 붙이세요</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>여기에 서명하려는 메시지를 입력하십시오</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>서명</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>현재 서명을 시스템 클립보드에 복사</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>여러분의 비트코인 주소를 증명하려면 메시지 서명하십시오</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>메시지에 서명(&amp;M)</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>메시지 필드의 모든 서명 재설정</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>모두 지우기(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>메시지 검증(&amp;V)</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>메시지를 검증하기 위해 아래 칸에 각각 지갑 주소와 메시지, 전자서명을 입력하세요. (메시지 원본의 띄어쓰기, 들여쓰기, 행 나눔 등이 정확하게 입력되어야 하므로 원본을 복사해서 입력하세요) 이 기능은 메시지 검증이 주 목적이며, 네트워크 침입자에 의해 변조되지 않도록 전자서명 해독에 불필요한 시간을 소모하지 마세요. </translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin address</source>
        <translation>정확한 비트코인주소가 입력됬는지 메시지를 확인하시오</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>메시지 검증(&amp;M)</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>모든 검증 메시지 필드 재설정</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>서명을 만들려면 "메시지 서명"을 누르십시오</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>입력한 주소가 잘못되었습니다.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>주소를 확인하고 다시 시도하십시오.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>입력한 주소는 키에서 참조하지 않습니다.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>지갑 잠금 해제를 취소했습니다.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>입력한 주소에 대한 개인키가 없습니다.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>메시지 서명에 실패했습니다.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>메시지를 서명했습니다.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>서명을 해독할 수 없습니다.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>서명을 확인하고 다시 시도하십시오.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>메시지 다이제스트와 서명이 일치하지 않습니다.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>메시지 검증에 실패했습니다.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>메시지를 검증했습니다.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>비트코인 코어</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>비트코인코어 개발자들</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[테스트넷]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>%1 까지 열림</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>충돌</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/오프라인</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/미확인</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 확인됨</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>상태</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>날짜</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>소스</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>생성하다</translation>
    </message>
    <message>
        <source>From</source>
        <translation>으로부터</translation>
    </message>
    <message>
        <source>To</source>
        <translation>에게</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>자신의 주소</translation>
    </message>
    <message>
        <source>label</source>
        <translation>라벨</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>예금</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>허용되지 않는다</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>차변</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>송금 수수료</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>총액</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>메시지</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>설명</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>아이디</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>상인</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>신규 채굴된 코인이 사용되기 위해서는 %1 개의 블럭이 경과되어야 합니다. 블럭을 생성할 때 블럭체인에 추가되도록 네트워크에 전파되는 과정을 거치는데, 블럭체인에 포함되지 못하고 실패한다면 해당 블럭의 상태는 '미승인'으로 표현되고 비트코인 또한 사용될 수 없습니다. 이 현상은 다른 노드가 비슷한 시간대에 동시에 블럭을 생성할 때 종종 발생할 수 있습니다. </translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>디버깅 정보</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>송금</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>입력</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>거래량</translation>
    </message>
    <message>
        <source>true</source>
        <translation>참</translation>
    </message>
    <message>
        <source>false</source>
        <translation>거짓</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>. 아직 성공적으로 통보하지 않음</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>알수없음</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>거래 세부 내역</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>이 창은 거래의 세부내역을 보여줍니다</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>날짜</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>종류</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>주소</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>충분히 숙성되지 않은 상태 (%1 승인, %2 후에 사용 가능합니다)</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>%1 까지 열림</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>확인됨(%1 확인됨)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>이 블럭은 다른 노드로부터 받지 않아 허용되지 않을 것임.</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>생성되었으나 거절됨</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>오프라인</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>미확인</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>승인 중 (권장되는 승인 회수 %2 대비 현재 승인 수 %1)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>충돌</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>보낸 주소</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>보낸 주소</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>받는 주소</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>자신에게 지불</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>채굴</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(없음)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>거래상황. 마우스를 올리면 승인횟수가 표시됩니다.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>거래가 이루어진 날짜와 시각.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>거래의 종류.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>거래가 도달할 주소</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>변경된 잔고.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>전체</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>오늘</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>이번주</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>이번 달</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>지난 달</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>올 해</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>범위...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>보낸 주소</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>받는 주소</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>자기거래</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>채굴</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>기타</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>검색하기 위한 주소 또는 표 입력</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>최소 거래량</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>주소 복사하기</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>표 복사하기</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>거래량 복사</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>거래 아이디 복사</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>표 수정하기</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>거래 내역 확인</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>거래 기록 내보내기</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>내보내기 실패</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>%1으로 거래 기록을 저장하는데 애러가 있었습니다.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>내보내기 성공</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>거래 기록이 성공적으로 %1에 저장되었습니다.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>각각의 파일에 쉼표하기(*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>확인됨</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>날짜</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>종류</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>표</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>주소</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>아이디</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>범위:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>상대방</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>지갑 불러오기가 안됩니다</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>코인들 보내기</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;내보내기</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>현재 탭에 있는 데이터를 파일로 내보내기</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>지갑 백업</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>지갑 데이터(*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>백업 실패</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>지갑 데이터를 %1 폴더에 저장하는 동안 오류가 발생했습니다. </translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>지갑 정보가 %1에 성공적으로 저장되었습니다</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>백업 성공</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>옵션:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>데이터 폴더 지정</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>피어 주소를 받기 위해 노드에 연결하고, 받은 후에 연결을 끊습니다</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>공인 주소를 지정하십시오</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>명령줄과 JSON-RPC 명령 수락</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>데몬으로 백그라운드에서 실행하고 명령을 허용</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>테스트 네트워크 사용</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>외부 접속을 승인합니다</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>선택된 주소로 고정하며 항상 리슨(Listen)합니다. IPv6 프로토콜인 경우  [host]:port 방식의 명령어 표기법을 사용합니다.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>지갑 거래가 바뀌면 명령을 실행합니다.(%s 안의 명령어가 TxID로 바뀝니다)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>이 빌드 버전은 정식 출시 전 테스트의 목적이며, 예기치 않은 위험과 오류가 발생할 수 있습니다. 채굴과 상점용 소프트웨어로 사용하는 것을 권하지 않습니다.</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>경고: -paytxfee값이 너무 큽니다! 이 값은 송금할때 지불할 송금 수수료입니다.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>경고 : 모든 네트워크가 동의해야 하나, 일부 채굴자들에게 문제가 있는 것으로 보입니다. </translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>경고: 현재 비트코인 버전이 다른 네트워크 참여자들과 동일하지 않는 것 같습니다. 당신 또는 다른 참여자들이 동일한 비트코인 버전으로 업그레이드 할 필요가 있습니다.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>경고 : wallet.dat 파일을 읽는 중 에러가 발생했습니다. 주소 키는 모두 정확하게 로딩되었으나 거래 데이터와 주소록 필드에서 누락이나 오류가 존재할 수 있습니다. </translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>경고 : wallet.dat가 손상되어 데이터가 복구되었습니다. 원래의 wallet.dat 파일은 %s 후에 wallet.{timestamp}.bak 이름으로 저장됩니다. 잔액과 거래 내역이 정확하지 않다면 백업 파일로 부터 복원해야 합니다. </translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(기본값: 1)</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>손상된 wallet.dat에서 개인키 복원을 시도합니다</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>블록 생성 옵션:</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>지정된 노드에만 연결하기</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>연결 설정 : </translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>손상된 블록 데이터베이스가 감지되었습니다</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>디버그 및 테스트 설정</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>자신의 아이피 주소를 발견합니다 (기본값: 1 반응이 없거나 외부 아이피가 없을 때)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>지갑 불러오기를 하지마시오 또한 지갑 RPC 연결을 차단하십시오</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>블락 데이터베이스를 다시 생성하시겠습니까?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>블록 데이터베이스를 초기화하는데 오류</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>블록 데이터베이스를 불러오는데 오류</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>블록 데이터베이스를 여는데 오류</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>오류: 디스크 공간이 부족합니다!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>어떤 포트도 반응하지 않습니다. 사용자 반응=0 만약 원한다면</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>&lt;카테고리&gt;가 제공되지 않을 경우, 모든 디버깅 정보를 출력</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>들여오기 중...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>올바르지 않거나 생성된 블록을 찾을 수 없습니다. 잘못된 네트워크 자료 디렉토리?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>잘못된 -onion 주소입니다: '%s'</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>사용 가능한 파일 디스크립터-File Descriptor-가 부족합니다. </translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>현재의 blk000??.dat 파일들로부터 블록체인 색인을 재구성합니다.</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>데이터베이스 케시 크기를 메가바이트로 설정(%d 부터 %d, 기본값: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>최대 블락 크기를 Bytes로 지정하세요 (기본: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>데이터 폴더 안에 지갑 파일을 선택하세요.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>블록 검증중...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>지갑 검증중...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>지갑 %s는 데이터 디렉토리 %s 밖에 위치합니다.</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>지갑 옵션:</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>-txindex를 바꾸기 위해서는 -reindex를 사용해서 데이터베이스를 재구성해야 합니다. </translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>외부 blk000??.dat 파일에서 블록을 가져옵니다.</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Bitcoin Core is probably already running.</source>
        <translation>데이터 디렉토리 %s에 락을 걸 수 없었습니다. 비트코인 코어가 이미 실행 중인 것으로 보입니다.</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>이 사항과 관련있는 경고가 발생하거나 아주 긴 포크가 발생했을 때 명령어를 실행해 주세요. (cmd 명령어 목록에서 %s는 메시지로 대체됩니다) </translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>최대 크기를 최우선으로 설정 / 바이트당 최소 수수료로 거래(기본값: %d)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>정보</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>노드로 전달하기 위한 최저 거래 수수료가 부족합니다. - minrelaytxfee=&lt;amount&gt;: '%s' -</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>최저 거래 수수료가 부족합니다. -mintxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>RPC SSL 옵션: (비트코인 위키의 SSL 설정 설명서 참고)</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC 서버 설정</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>모든 네트워크 메시지 마다 무작위로 1이 떨어진다</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>추적오류 정보를 degug.log 자료로 보내는 대신 콘솔로 보내기</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>모든 디버그 설정 보기(설정: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>클라이언트 시작시 debug.log 파일 비우기(기본값: 디버그 안할때 1)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>거래를 서명하는것을 실패하였습니다.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>거래량이 너무 적습니다</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>거래량은 반드시 정수여야합니다.</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>너무 큰 거래</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>UPnP사용하여 지도에서 포트 반응기다리는 중  (기본값: 1 반응이 생기면)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>JSON-RPC 연결에 사용할 사용자 이름</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>경고</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>경고: 이 버전이 오래되어 업그레이드가 필요합니다!</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>지갑의 모든거래내역 건너뛰기...</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>구동 중</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat 파일이 손상되었고 복구가 실패하였습니다.</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>JSON-RPC 연결에 사용할 암호</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>최고의 블럭이 변하면 명령을 실행(cmd 에 있는 %s 는 블럭 해시에 의해 대체되어 짐)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>지갑을 최근 형식으로 개선하시오</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>누락된 지갑 송금에 대한 블록 체인 다시 검색</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>JSON-RPC 연결에 OpenSSL(https) 사용</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>도움말 메시지입니다</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>-addnode, -seednode, -connect 옵션에 대해 DNS 탐색 허용</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>주소를 불러오는 중...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>wallet.dat 불러오기 에러: 지갑 오류</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>wallet.dat 불러오기 에러</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>잘못된 -proxy 주소입니다: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>-onlynet에 지정한 네트워크를 알 수 없습니다: '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: '%s'</source>
        <translation>-bind 주소를 확인할 수 없습니다: '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: '%s'</source>
        <translation>-externalip 주소를 확인할 수 없습니다: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>-paytxfee=&lt;amount&gt;에 대한 양이 잘못되었습니다: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>자금 부족</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>블럭 인덱스를 불러오는 중...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>노드를 추가하여 연결하고 연결상태를 계속 유지하려고 시도합니다.</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>지갑을 불러오는 중...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>지갑을 다운그레이드 할 수 없습니다</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>기본 계좌에 기록할 수 없습니다</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>재검색 중...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>로딩 완료</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>오류</translation>
    </message>
</context>
</TS>