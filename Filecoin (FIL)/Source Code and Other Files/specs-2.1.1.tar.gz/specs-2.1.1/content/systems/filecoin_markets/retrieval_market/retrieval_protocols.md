---
title: 'Retrieval Protocols'
weight: 2
dashboardWeight: 2
dashboardState: stable
dashboardAudit: n/a
dashboardTests: 0
---

# Retrieval Protocols

The `retrieval market` is implemented using the following `libp2p` service.

{{<hint info >}}
**Name**: Query Protocol
**Protocol ID**: `/fil/<network-name>/retrieval/qry/1.0.0`
{{</hint>}}

Request: CBOR Encoded RetrievalQuery Data Structure
Response: CBOR Encoded RetrievalQueryResponse Data Structure
