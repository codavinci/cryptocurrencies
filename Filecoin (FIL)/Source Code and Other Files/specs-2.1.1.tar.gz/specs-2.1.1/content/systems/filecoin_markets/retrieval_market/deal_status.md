---
title: 'Retrieval Deal Status'
weight: 5
dashboardWeight: 2
dashboardState: stable
dashboardAudit: n/a
dashboardTests: 0
---

# Retrieval Deal Status

{{<embed src="https://github.com/filecoin-project/go-fil-markets/blob/master/retrievalmarket/dealstatus.go"  lang="go">}}
