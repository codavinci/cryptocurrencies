---
title: Storage Proving
weight: 4
bookCollapseSection: true
dashboardWeight: 1
dashboardState: wip
dashboardAudit: wip
dashboardTests: 0
---

# Storage Proving

## Filecoin Proving Subsystem

{{<embed src="storage_proving_subsystem.id"  lang="go" >}}
