---
title: Sector Poster
dashboardWeight: 1
dashboardState: wip
dashboardAudit: wip
dashboardTests: 0
---

# Sector Poster

## PoSt Generator object

{{<embed src="post_generator.id"  lang="go" >}}

{{<embed src="post_generator.go"  lang="go" >}}
