---
title: Storage Miner Actor
weight: 5
dashboardWeight: 2
dashboardState: wip
dashboardAudit: done
dashboardAuditURL: /#section-appendix.audit_reports.actors
dashboardAuditDate: '2020-10-19'
dashboardTests: 0
---

# Storage Miner Actor

{{<embed src="https://github.com/filecoin-project/specs-actors/blob/master/actors/builtin/miner/miner_state.go"  lang="go" symbol="State" title="Storage Miner Actor State">}}

{{<embed src="https://github.com/filecoin-project/specs-actors/blob/master/actors/builtin/miner/miner_actor.go"  lang="go" title="Storage Miner Actor">}}
