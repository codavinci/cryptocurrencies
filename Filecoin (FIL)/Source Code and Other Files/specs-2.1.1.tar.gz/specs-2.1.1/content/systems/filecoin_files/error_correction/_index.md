---
title: Error Correction
weight: 5
bookCollapseSection: true
draft: true
---

# Forward Error Correction and Erasure Codes

In order to reduce likelihood of problems,`Clients` prepare their data by
applying erasure or error correcting codes. This section describes how
that will happen.

{{< hint warning >}}
TODO
{{< /hint >}}
