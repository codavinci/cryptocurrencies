---
title: File
weight: 1
bookCollapseSection: true
dashboardWeight: 1
dashboardState: reliable
dashboardAudit: n/a
dashboardTests: 0
---

# File

{{< embed src="file.id" lang="go" >}}
