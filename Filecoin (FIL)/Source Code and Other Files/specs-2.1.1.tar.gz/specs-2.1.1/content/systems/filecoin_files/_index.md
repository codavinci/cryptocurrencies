---
title: Files & Data
bookCollapseSection: true
weight: 2

dashboardWeight: 1.5
dashboardState: reliable
dashboardAudit: n/a
dashboardTests: 0
---

# Files & Data

Filecoin's primary aim is to store client's Files and Data.
This section details data structures and tooling related to working with files,
chunking, encoding, graph representations, `Pieces`, storage abstractions, and more.
