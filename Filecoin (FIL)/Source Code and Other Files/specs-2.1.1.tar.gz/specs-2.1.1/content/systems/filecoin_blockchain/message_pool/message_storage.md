---
title: Message Storage
weight: 2
dashboardWeight: 2
dashboardState: stable
dashboardAudit: n/a
dashboardTests: 0
---

# Message Storage

As mentioned earlier, there is no central pool where messages are included. Instead, every node must have allocated memory for incoming messages.
