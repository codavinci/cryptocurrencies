---
title: Genesis
description: Genesis - starting the Blockchain
weight: 6
draft: true
---

# Genesis - starting the Blockchain

{{< hint warning >}}
**WARNING:** This section is not yet complete.
{{< /hint >}}

Network Bootstrapping starts with production of the genesis block.

The genesis block will contain: - An initial participant set, including committed storage from these miners (pre-sealed using special-cased randomness) - An initial randomness ticket
