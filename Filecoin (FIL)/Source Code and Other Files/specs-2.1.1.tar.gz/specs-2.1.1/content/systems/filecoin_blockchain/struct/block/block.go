package block

// The maximum sum of the size of the serialized messages included in a block.
const BlockMaxSize = 512 * 1024

// The maximum sum of the gas limits of the messages included in a block.
const BlockGasLimit = 0 // Placeholder
