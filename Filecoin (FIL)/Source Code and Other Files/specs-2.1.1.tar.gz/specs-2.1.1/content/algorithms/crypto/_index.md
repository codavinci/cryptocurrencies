---
title: 'Cryptographic Primitives'
bookCollapseSection: true
weight: 7
dashboardWeight: 2
dashboardState: wip
dashboardAudit: n/a
dashboardTests: 0
---

# Cryptographic Primitives

- Merkle tree/DAG
- Vector commitment scheme
- zkSNARK
- Reliable broadcast channel (libp2p)

- TODO: Add more detail and include references to relevant papers.
