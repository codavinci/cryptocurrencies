function name() {
  return 1
}
