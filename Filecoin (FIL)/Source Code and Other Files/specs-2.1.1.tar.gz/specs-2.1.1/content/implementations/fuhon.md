---
title: Fuhon
weight: 4
dashboardWeight: 1
dashboardState: reliable
dashboardAudit: n/a
implRepos:
  - { lang: c++, repo: https://github.com/filecoin-project/cpp-filecoin }
---

# Fuhon (cpp-filecoin)

Fuhon is the C++ implementation of Filecoin. The implementation uses Rust libraries for BLS, so Rust is needed in order to build successfully.

You can find the Fuhon codebase [here](https://github.com/filecoin-project/cpp-filecoin).

The Fuhon implementation of Filecoin is supported by [Soramitsu](https://soramitsu.co.jp/).
