---
title: 'Architecture Diagrams'
audit: 1
dashboardWeight: 0.2
dashboardState: reliable
dashboardAudit: n/a
---

# Architecture Diagrams

Actor State Diagram

![Actor State Diagram](/intro/new-state-diagram.mmd)
