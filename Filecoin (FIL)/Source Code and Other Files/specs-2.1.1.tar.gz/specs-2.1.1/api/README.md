## Usage

Install Cloudflare Wrangler

```bash
wrangler login # to get the token

wrangler publish # to publish the worker to specs-api.protocol-labs.workers.dev
```
