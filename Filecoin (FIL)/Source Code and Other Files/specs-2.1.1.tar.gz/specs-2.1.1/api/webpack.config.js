module.exports = {
  target: 'webworker',
  devtool: 'cheap-module-source-map',
  entry: './index.js',
  mode: 'development',
}
