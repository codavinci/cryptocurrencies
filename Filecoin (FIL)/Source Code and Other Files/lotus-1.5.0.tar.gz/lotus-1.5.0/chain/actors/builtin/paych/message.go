package paych

import (
	"fmt"

	"github.com/filecoin-project/go-address"
	"github.com/filecoin-project/go-state-types/abi"
	"github.com/filecoin-project/lotus/chain/actors"
	"github.com/filecoin-project/lotus/chain/types"

	builtin3 "github.com/filecoin-project/specs-actors/v3/actors/builtin"
)

var Methods = builtin3.MethodsPaych

func Message(version actors.Version, from address.Address) MessageBuilder {
	switch version {
	case actors.Version0:
		return message0{from}
	case actors.Version2:
		return message2{from}
	case actors.Version3:
		return message3{from}
	default:
		panic(fmt.Sprintf("unsupported actors version: %d", version))
	}
}

type MessageBuilder interface {
	Create(to address.Address, initialAmount abi.TokenAmount) (*types.Message, error)
	Update(paych address.Address, voucher *SignedVoucher, secret []byte) (*types.Message, error)
	Settle(paych address.Address) (*types.Message, error)
	Collect(paych address.Address) (*types.Message, error)
}
