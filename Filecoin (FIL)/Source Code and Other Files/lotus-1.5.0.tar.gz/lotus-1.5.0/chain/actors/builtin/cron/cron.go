package cron

import (
	builtin3 "github.com/filecoin-project/specs-actors/v3/actors/builtin"
)

var (
	Address = builtin3.CronActorAddr
	Methods = builtin3.MethodsCron
)
