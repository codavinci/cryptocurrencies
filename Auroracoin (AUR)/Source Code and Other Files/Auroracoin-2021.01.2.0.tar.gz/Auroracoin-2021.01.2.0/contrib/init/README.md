Sample configuration files for:
```
SystemD: digibyted.service
Upstart: digibyted.conf
OpenRC:  digibyted.openrc
         digibyted.openrcconf
CentOS:  digibyted.init
macOS:   org.auroracoin.auroracoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
