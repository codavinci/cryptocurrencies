Thread names in logs
--------------------

On platforms supporting `thread_local`, log lines can be prefixed with the name
of the thread that caused the log. To enable this behavior, use
`-logthreadnames=1`.