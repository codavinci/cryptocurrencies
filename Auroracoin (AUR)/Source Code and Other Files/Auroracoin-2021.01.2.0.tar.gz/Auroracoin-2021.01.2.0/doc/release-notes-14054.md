P2P changes
-----------

BIP 61 reject messages were deprecated in v0.18. They are now disabled by
default, but can be enabled by setting the `-enablebip61` command line option.
BIP 61 reject messages will be removed entirely in a future version of
Bitcoin Core.