#!/usr/bin/env python3
# Copyright (c) 2013-2017 The DigiByte Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

SRCDIR="/Users/jaredtate/Code/auroracoin"
BUILDDIR="/Users/jaredtate/Code/auroracoin"
EXEEXT=""

# These will turn into comments if they were disabled when configuring.
ENABLE_WALLET=1
ENABLE_UTILS=1
ENABLE_AURORACOIND=1
#ENABLE_ZMQ=1
