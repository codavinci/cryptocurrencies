#ifndef SKEIN_H
#define SKEIN_H
#include <stdlib.h>
#include <stdint.h>

void skein(const char *input, char *output);

#endif
