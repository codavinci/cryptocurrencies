#ifndef GROESTL_H
#define GROESTL_H
#include <stdlib.h>
#include <stdint.h>

void groestl(const char *input, char *output);

#endif
