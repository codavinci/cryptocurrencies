#ifndef QUBIT_H
#define QUBIT_H
#include <stdlib.h>
#include <stdint.h>

uint256 qubit(const char *input);

#endif
