using System.Windows.Forms;

namespace Neo.GUI
{
    internal partial class DeveloperToolsForm : Form
    {
        public DeveloperToolsForm()
        {
            InitializeComponent();
            InitializeTxBuilder();
        }
    }
}
