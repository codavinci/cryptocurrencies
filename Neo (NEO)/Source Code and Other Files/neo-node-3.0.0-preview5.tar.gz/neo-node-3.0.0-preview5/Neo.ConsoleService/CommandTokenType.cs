namespace Neo.ConsoleService
{
    internal enum CommandTokenType : byte
    {
        String,
        Space,
        Quote,
    }
}
