using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Neo.ConsoleService.Tests")]
