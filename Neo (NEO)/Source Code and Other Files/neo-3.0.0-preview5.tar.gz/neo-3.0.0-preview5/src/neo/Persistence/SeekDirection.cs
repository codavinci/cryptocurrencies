namespace Neo.Persistence
{
    public enum SeekDirection : sbyte
    {
        Forward = 1,
        Backward = -1
    }
}
