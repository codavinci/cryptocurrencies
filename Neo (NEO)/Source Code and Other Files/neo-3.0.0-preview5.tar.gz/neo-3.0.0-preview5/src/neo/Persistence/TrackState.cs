namespace Neo.Persistence
{
    public enum TrackState : byte
    {
        None,
        Added,
        Changed,
        Deleted
    }
}
