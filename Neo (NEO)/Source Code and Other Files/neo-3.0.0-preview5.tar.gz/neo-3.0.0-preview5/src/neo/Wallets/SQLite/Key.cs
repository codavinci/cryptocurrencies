namespace Neo.Wallets.SQLite
{
    internal class Key
    {
        public string Name { get; set; }
        public byte[] Value { get; set; }
    }
}
