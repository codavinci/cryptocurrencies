namespace Neo.SmartContract.Native
{
    public enum Role : byte
    {
        StateValidator = 4,
        Oracle = 8
    }
}
