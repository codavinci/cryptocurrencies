namespace Neo.SmartContract
{
    public class StorageContext
    {
        public int Id;
        public bool IsReadOnly;
    }
}
